from __future__ import annotations

from PyQt6.QtCore import QBuffer, QByteArray, QIODevice, QMimeData, QRectF
from PyQt6.QtGui import QClipboard, QGuiApplication, QPainter, QPixmap
from PyQt6.QtPrintSupport import QPrintDialog, QPrinter
from PyQt6.QtSvg import QSvgGenerator
from PyQt6.QtWidgets import QWidget


def copy_widget_to_clipboard(widget: QWidget, scale: float = 2.0) -> None:
    """ウィジェットを高解像度PNG＋SVGとしてクリップボードにコピーする。

    複数のMIMEタイプを同時にセットすることで、貼り付け先アプリがラスター(PNG)/
    ベクター(SVG)どちらを解釈できるかに応じて選べるようにする。
    EMF(拡張メタファイル)はWindows固有形式でクロスプラットフォームなQt APIからは
    生成できないため、ベクター形式の代替としてSVGを提供する。
    """
    size = widget.size()
    if size.width() <= 0 or size.height() <= 0:
        return

    pixmap = QPixmap(int(size.width() * scale), int(size.height() * scale))
    pixmap.setDevicePixelRatio(scale)
    pixmap.fill(0xFFFFFFFF)  # 白背景（透過だと多くの貼り付け先で黒背景になるため）
    png_painter = QPainter(pixmap)
    widget.render(png_painter)
    png_painter.end()

    svg_bytes = QByteArray()
    buffer = QBuffer(svg_bytes)
    buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    generator = QSvgGenerator()
    generator.setOutputDevice(buffer)
    generator.setSize(size)
    generator.setViewBox(QRectF(0, 0, size.width(), size.height()))
    svg_painter = QPainter(generator)
    widget.render(svg_painter)
    svg_painter.end()
    buffer.close()

    mime = QMimeData()
    mime.setImageData(pixmap.toImage())
    mime.setData("image/svg+xml", svg_bytes)
    QGuiApplication.clipboard().setMimeData(mime, QClipboard.Mode.Clipboard)


def render_to_printer(widget: QWidget, printer: QPrinter) -> None:
    """ウィジェットをQPrinterのページ領域に、アスペクト比を保ったまま描画する。

    print_widget()とテストコードの両方から呼べるよう、ダイアログ表示ロジックと分離している。
    """
    painter = QPainter(printer)
    try:
        target_rect = painter.viewport()
        src_rect = widget.rect()
        scale = min(
            target_rect.width() / src_rect.width(),
            target_rect.height() / src_rect.height(),
        )
        painter.translate(target_rect.center())
        painter.scale(scale, scale)
        painter.translate(-src_rect.center())
        widget.render(painter)
    finally:
        painter.end()


def print_widget(widget: QWidget, parent=None) -> bool:
    """標準の印刷ダイアログを表示し、選択されたプリンタ（PDF出力含む）に描画する。

    ダイアログでキャンセルされた場合はFalseを返す。
    """
    printer = QPrinter(QPrinter.PrinterMode.HighResolution)
    dialog = QPrintDialog(printer, parent)
    if dialog.exec() != QPrintDialog.DialogCode.Accepted:
        return False

    render_to_printer(widget, printer)
    return True
