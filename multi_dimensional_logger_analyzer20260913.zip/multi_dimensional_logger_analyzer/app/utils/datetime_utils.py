from __future__ import annotations

import re
from datetime import date, datetime

import numpy as np
import pandas as pd

# ファイル名から日付を抽出するパターン（優先順、YYYYMMDD系のみ確実に判定）
_DATE_PATTERN = re.compile(r"(\d{4})[-_]?(\d{2})[-_]?(\d{2})")


def extract_date_from_filename(filename: str) -> date | None:
    """ファイル名から YYYYMMDD 形式の日付を抽出する。

    見つからない、または不正な日付（例: 13月）の場合は None を返し、
    呼び出し側（GUI）でユーザーに手動指定を促す。
    """
    m = _DATE_PATTERN.search(filename)
    if not m:
        return None
    y, mo, d = m.groups()
    try:
        return datetime.strptime(f"{y}{mo}{d}", "%Y%m%d").date()
    except ValueError:
        return None


def combine_date_and_time(base_date, time_series: pd.Series) -> np.ndarray:
    """日付（date または日付文字列）と時刻列を結合し datetime64[ns] 配列を返す。

    Args:
        base_date: date オブジェクト、または日付として解釈可能な文字列
        time_series: 時刻文字列を含む pandas.Series
    """
    if isinstance(base_date, str):
        base_date = pd.to_datetime(base_date).date()

    # "0:0:5" や "10:06:42" のようなH:M:S形式をまず一括（ベクトル化）でパースする。
    # フォーマットを明示することで、1行ずつ個別にdateutilへフォールバックする際に出る
    # "Could not infer format" 警告や、それに伴う処理速度の低下を避ける。
    text = time_series.astype(str).str.strip()
    parsed = pd.to_datetime(text, format="%H:%M:%S", errors="coerce")
    if parsed.isna().any():
        # 想定外の書式（秒に小数を含む等）の行だけ、個別に緩い解析でフォールバックする。
        fallback = pd.to_datetime(text[parsed.isna()], errors="coerce")
        parsed.loc[fallback.index] = fallback

    combined = parsed.apply(
        lambda t: datetime.combine(base_date, t.time()) if pd.notna(t) else pd.NaT
    )
    return combined.to_numpy(dtype="datetime64[ns]")
