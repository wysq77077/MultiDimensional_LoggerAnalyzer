from __future__ import annotations

import numpy as np

from app.core.data_manager import DataManager
from app.gui.right_panel.graph_widget import GraphMode, GraphWidget
from app.gui.right_panel.map_widget import MapWidget


class SyncController:
    """グラフの時刻選択/表示範囲と、地図のピン移動/表示範囲を仲介するクラス（Mediator）。

    GraphWidgetとMapWidgetは互いを直接参照しない。両者を仲介するのは本クラスのみとし、
    将来どちらかのWidget実装を差し替えても影響範囲をここに閉じ込める。

    以下2方向の連携を扱う（無限ループにならない設計は各Widget側のガードで担保）:
    - グラフをズーム/パン (view_range_changed) -> 地図上の表示点をその時間帯に絞り込む
    - 地図をパン/ズーム (visible_range_changed) -> グラフの表示範囲をその時間帯にズームする
    """

    def __init__(self, graph_widget: GraphWidget, map_widget: MapWidget, data_manager: DataManager):
        self._graph_widget = graph_widget
        self._map_widget = map_widget
        self._data_manager = data_manager
        self._graph_widget.time_clicked.connect(self._on_time_clicked)
        self._graph_widget.view_range_changed.connect(self._on_graph_view_range_changed)
        self._map_widget.visible_range_changed.connect(self._on_map_visible_range_changed)

    def _on_time_clicked(self, t) -> None:
        dataset = self._data_manager.dataset
        if dataset is None or not dataset.is_gps():
            return

        # 日変化モード（時刻のみで日付情報を持たない）は同期対象外。将来、当日／選択日と
        # 合成して対応することも可能だが、複数日が重なるため意味が曖昧になるため見送っている。
        if self._graph_widget.mode != GraphMode.NORMAL:
            return
        if not isinstance(t, np.datetime64):
            return

        idx = dataset.nearest_index(t)
        lat = dataset.columns["latitude"][idx]
        lon = dataset.columns["longitude"][idx]
        self._map_widget.move_marker(lat, lon)

    def _on_graph_view_range_changed(self, start_sec: float, end_sec: float) -> None:
        """グラフのズーム/パン結果を受けて、地図上に表示する点をその時間帯に絞り込む。"""
        dataset = self._data_manager.dataset
        if dataset is None or not dataset.is_gps():
            return
        self._map_widget.filter_by_time(start_sec, end_sec)

    def _on_map_visible_range_changed(self, start_sec: float, end_sec: float) -> None:
        """地図のパン/ズーム結果を受けて、グラフの表示範囲をその時間帯にズームする。"""
        dataset = self._data_manager.dataset
        if dataset is None or not dataset.is_gps():
            return
        if self._graph_widget.mode != GraphMode.NORMAL:
            return
        self._graph_widget.set_time_range(start_sec, end_sec)
