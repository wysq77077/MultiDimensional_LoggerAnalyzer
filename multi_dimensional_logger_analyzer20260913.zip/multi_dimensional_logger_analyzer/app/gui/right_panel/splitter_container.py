from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QSplitter, QStackedWidget, QVBoxLayout, QWidget

from app.gui.right_panel.graph_widget import GraphWidget
from app.gui.right_panel.log_panel import LogPanel
from app.gui.right_panel.map_widget import MapWidget


class SplitterContainer(QWidget):
    """右側パネル（上段:グラフ、下段:地図 or ログ）をQSplitterで管理するクラス。

    下段はQStackedWidgetで地図(MapWidget)とログ(LogPanel)を切り替える。
    GPSデータが無い場合や、ユーザーが地図表示をOFFにした場合は、その領域を
    空白/非表示にする代わりにログパネルを表示することで、下段を常に有効活用する。
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        self.graph_widget = GraphWidget()
        self.map_widget = MapWidget()
        self.log_panel = LogPanel()

        self._bottom_stack = QStackedWidget()
        self._bottom_stack.addWidget(self.map_widget)
        self._bottom_stack.addWidget(self.log_panel)
        self._bottom_stack.setMinimumHeight(80)

        self._splitter = QSplitter(Qt.Orientation.Vertical)
        self._splitter.addWidget(self.graph_widget)
        self._splitter.addWidget(self._bottom_stack)
        self._splitter.setStretchFactor(0, 3)
        self._splitter.setStretchFactor(1, 2)
        self._saved_sizes = self._splitter.sizes()

        layout = QVBoxLayout(self)
        layout.addWidget(self._splitter)
        layout.setContentsMargins(0, 0, 0, 0)

        self.show_log()  # 起動直後（データ未読み込み）はログ表示をデフォルトにする

    def show_map(self) -> None:
        """下段エリアに地図を表示する。"""
        self._bottom_stack.setCurrentWidget(self.map_widget)
        self._restore_bottom_area()

    def show_log(self) -> None:
        """下段エリアにログを表示する（GPSデータが無い場合の既定表示）。"""
        self._bottom_stack.setCurrentWidget(self.log_panel)
        self._restore_bottom_area()

    def _restore_bottom_area(self) -> None:
        sizes = self._saved_sizes if sum(self._saved_sizes) > 0 else [3, 2]
        self._splitter.setSizes(sizes)

    def set_map_visible(self, visible: bool) -> None:
        """GPSチェックボックスのON/OFFに連動する。

        ON: 下段に地図を表示。OFF: 下段を非表示にはせず、代わりにログを表示する
        （地図が無い間、下段エリアを空白のまま遊ばせないようにするため）。
        """
        if visible:
            self.show_map()
        else:
            self.show_log()
