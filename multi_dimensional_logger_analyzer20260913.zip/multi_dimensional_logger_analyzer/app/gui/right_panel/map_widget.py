from __future__ import annotations

import functools
import json
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
from PyQt6.QtCore import QObject, QUrl, pyqtSignal, pyqtSlot
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtWebEngineCore import QWebEngineProfile
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QApplication, QVBoxLayout, QWidget

_ASSETS_DIR = Path(__file__).parent / "map_assets"
_INDEX_HTML = _ASSETS_DIR / "index.html"
_MAX_TRACK_POINTS = 5000  # ブラウザ側のポリライン描画負荷を抑えるための間引き上限

# OSM Tile Usage Policy等が推奨する「識別可能なUser-Agent」を明示する。
# 参考: https://operations.osmfoundation.org/policies/tiles/
# 注意: これは行儀の良いUAを名乗るためのものであり、NETWORK_ACCESS_DENIED
# （OS/ファイアウォール側でTCP接続自体がブロックされるエラー）の対策にはならない。
# そのエラーはHTTPリクエストが送信される前の段階で発生するため、
# User-Agentの内容とは無関係。
_MAP_USER_AGENT = "MultiDimensionalLoggerAnalyzer/1.0 (desktop GPS log viewer)"


class _MapAssetServer:
    """map_assets配下を配信するだけの、ローカル専用の使い捨てHTTPサーバー。

    file://でindex.htmlを読み込むと、そのページから外部https(タイルサーバー)への
    リクエストが "Origin: null" として送出される。この形のリクエストは一部の
    セキュリティソフト(Norton等のWeb保護/侵入防止機能)から「素性不明な通信」として
    宛先ドメインに関わらず一律ブロックされることがある実運用上の問題を確認済み。
    http://127.0.0.1:<port>/ 経由でindex.htmlを読み込ませることで、通常のブラウザで
    サイトを閲覧する場合と同じ形のOriginにしてこの問題を回避する。

    127.0.0.1のみへのバインドで、ポートは起動時に空いているものを自動選択するため、
    外部からの接続や固定ポートの衝突は発生しない。
    """

    def __init__(self, directory: Path):
        handler = functools.partial(SimpleHTTPRequestHandler, directory=str(directory))
        # port=0 を指定するとOSが空いているポートを自動的に割り当てる。
        self._httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()

    @property
    def port(self) -> int:
        return self._httpd.server_address[1]

    def shutdown(self) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()


class _MapBridge(QObject):
    """地図の表示範囲(パン/ズーム)変更をPython側へ伝えるQWebChannelブリッジ。

    JS側は地図の 'moveend' イベントごとに、現在表示範囲内にある軌跡点の
    時刻(エポック秒)の最小値・最大値を reportVisibleRange() 経由で呼び出す。
    """

    visible_range_changed = pyqtSignal(float, float)  # (start_epoch_sec, end_epoch_sec)

    @pyqtSlot(float, float)
    def reportVisibleRange(self, start_sec: float, end_sec: float) -> None:  # noqa: N802 (JS側の呼び出し名に合わせる)
        self.visible_range_changed.emit(start_sec, end_sec)


class MapWidget(QWidget):
    """OpenStreetMap上に軌跡・ピンを表示するウィジェット。

    Leaflet本体(JS/CSS/マーカー画像)はローカル同梱（map_assets/leaflet/）のため、
    地図の枠組み自体はオフラインでも初期化できる。ただしタイル画像は
    OpenStreetMapから取得するため、実際の地図表示には実行時のネット接続が必要。

    ページ読み込み完了前に呼ばれたJS実行要求はキューに積み、loadFinished後にまとめて実行する。

    グラフ側との時間軸連携(SyncController経由)のため、以下の双方向シグナル/メソッドを持つ:
    - visible_range_changed: 地図をパン/ズームした際、表示範囲内の軌跡点の時刻レンジを通知する
    - filter_by_time(): グラフ側の表示範囲(ズーム)に応じて、地図上に表示する点を絞り込む
    """

    visible_range_changed = pyqtSignal(float, float)  # (start_epoch_sec, end_epoch_sec)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._view = QWebEngineView()
        self._view.page().profile().setHttpUserAgent(_MAP_USER_AGENT)
        self._loaded = False
        self._pending_calls: list[str] = []

        self._bridge = _MapBridge()
        self._bridge.visible_range_changed.connect(self.visible_range_changed)
        self._channel = QWebChannel()
        self._channel.registerObject("mapBridge", self._bridge)
        self._view.page().setWebChannel(self._channel)

        # file://での読み込みはOrigin: nullなリクエストになり、一部のセキュリティ
        # ソフトに通信自体を遮断されることがあるため、ローカルHTTPサーバー経由で読み込む。
        self._asset_server = _MapAssetServer(_ASSETS_DIR)
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._asset_server.shutdown)

        self._view.loadFinished.connect(self._on_load_finished)
        self._view.load(QUrl(f"http://127.0.0.1:{self._asset_server.port}/index.html"))

        layout = QVBoxLayout(self)
        layout.addWidget(self._view)
        layout.setContentsMargins(0, 0, 0, 0)

    def set_track(
        self,
        latitudes: np.ndarray,
        longitudes: np.ndarray,
        timestamps: np.ndarray | None = None,
    ) -> None:
        """GPS軌跡を赤い点として描画し、その範囲にズームを合わせる。

        timestamps（dataset.timestamps相当のdatetime64[ns]配列、または同じ長さの
        エポック秒配列）を渡すと、地図の表示範囲(パン/ズーム)に応じてグラフ側の
        表示範囲を絞り込む連携(visible_range_changedシグナル)が有効になる。
        省略時、またはlatitudes/longitudesと長さが一致しない場合は、軌跡の表示のみ
        行い、時間軸連携は無効のままになる。
        """
        latitudes = np.asarray(latitudes, dtype=float)
        longitudes = np.asarray(longitudes, dtype=float)
        n = len(latitudes)

        ts = None
        if timestamps is not None and len(timestamps) == n:
            ts = np.asarray(timestamps)

        lat, lon, ts = self._decimate(latitudes, longitudes, ts)

        valid = ~(np.isnan(lat) | np.isnan(lon))
        # (緯度, 経度) = (0, 0) はGPS未補足時の代表的なダミー値であり、実際の軌跡として
        # 扱うと地図の表示範囲が赤道/本初子午線付近まで無用に広がってしまうため除外する。
        valid = valid & ~((np.abs(lat) < 1e-9) & (np.abs(lon) < 1e-9))
        times_json = "null"
        if ts is not None:
            if np.issubdtype(ts.dtype, np.datetime64):
                valid = valid & ~np.isnat(ts)
                epoch = ts.astype("datetime64[s]").astype(np.int64).astype(float)
            else:
                ts = ts.astype(float)
                valid = valid & ~np.isnan(ts)
                epoch = ts
            times_json = json.dumps([float(x) for x in epoch[valid]])

        coords = [[float(a), float(b)] for a, b in zip(lat[valid], lon[valid])]
        self._run_js(f"setTrack({json.dumps(coords)}, {times_json});")

    def filter_by_time(self, start_sec: float | None, end_sec: float | None) -> None:
        """グラフ側の表示範囲(拡大/縮小)に応じて、地図上に表示する軌跡点を絞り込む。

        start_sec/end_secはエポック秒(float)。Noneの場合は絞り込みを解除して全点表示する。
        """
        if start_sec is None or end_sec is None:
            self._run_js("filterTrackByTime(null, null);")
        else:
            self._run_js(f"filterTrackByTime({float(start_sec)}, {float(end_sec)});")

    def move_marker(self, lat: float, lon: float) -> None:
        """指定座標へピンを移動する（グラフ側の時刻選択との同期用）"""
        if lat is None or lon is None or np.isnan(lat) or np.isnan(lon):
            return
        self._run_js(f"moveMarker({float(lat)}, {float(lon)});")

    def clear_marker(self) -> None:
        self._run_js("clearMarker();")

    def _decimate(self, latitudes: np.ndarray, longitudes: np.ndarray, timestamps):
        n = len(latitudes)
        if n <= _MAX_TRACK_POINTS:
            return latitudes, longitudes, timestamps
        idx = np.linspace(0, n - 1, _MAX_TRACK_POINTS).astype(np.int64)
        ts = timestamps[idx] if timestamps is not None else None
        return latitudes[idx], longitudes[idx], ts

    def _run_js(self, script: str) -> None:
        if self._loaded:
            self._view.page().runJavaScript(script)
        else:
            self._pending_calls.append(script)

    def _on_load_finished(self, ok: bool) -> None:
        self._loaded = ok
        if not ok:
            return
        for script in self._pending_calls:
            self._view.page().runJavaScript(script)
        self._pending_calls.clear()
