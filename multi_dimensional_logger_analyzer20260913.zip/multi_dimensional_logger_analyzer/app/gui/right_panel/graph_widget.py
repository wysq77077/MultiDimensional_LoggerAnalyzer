from __future__ import annotations

import math
from datetime import datetime, timezone
from enum import Enum, auto

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import QRectF, pyqtSignal

from app.core.downsampler import Downsampler


class GraphMode(Enum):
    NORMAL = auto()          # 通常モード（連続時系列、min/max帯＋mean線）
    DAILY_OVERLAY = auto()   # 日変化モード（0:00-23:59に重ね合わせ）
    HISTOGRAM = auto()       # 累積出現度数モード（対称対数の百分率軸）


_DEFAULT_LINE_COLOR = (30, 80, 200)

# 時間軸（通常/日変化モード）の「切りのいい」目盛り間隔の候補（秒）。
# 小さい方から順に見て、ラベルが重ならない最小間隔を満たす最初の値を採用する。
_NICE_TIME_STEPS_SEC = [
    1, 2, 5, 10, 15, 30,
    60, 120, 300, 600, 900, 1800,
    3600, 2 * 3600, 3 * 3600, 6 * 3600, 12 * 3600,
    86400, 2 * 86400, 5 * 86400, 7 * 86400, 14 * 86400, 30 * 86400,
    90 * 86400, 180 * 86400, 365 * 86400,
]


def _choose_nice_time_step(span: float, size_px: float, min_px_per_tick: float = 70.0) -> float:
    """軸の描画幅(size_px)に対して、ラベルが重ならない「切りのいい」時間刻み(秒)を選ぶ。

    候補(_NICE_TIME_STEPS_SEC)は秒/分/時/日の境界に対応する値のみで構成しているため、
    選ばれた刻みで生成する目盛りは常に「何時ちょうど」等の丸い時刻に揃う。
    """
    if span <= 0 or size_px <= 0:
        return _NICE_TIME_STEPS_SEC[0]
    max_ticks = max(int(size_px / min_px_per_tick), 1)
    target_step = span / max_ticks
    for step in _NICE_TIME_STEPS_SEC:
        if step >= target_step:
            return step
    return _NICE_TIME_STEPS_SEC[-1]


# 累積出現度数プロットの縦軸目盛り候補。中心(50%)から優先度順に並べており、
# アダプティブ間引き(_CumulativeFreqAxis.tickValues)では、この順に
# 「まだ採用した目盛りと重ならない」ものだけを追加していく。
_PERCENTILE_TICK_PRIORITY = [
    50,
    10, 90,
    1, 99,
    0.1, 99.9,
    5, 95,
    20, 80,
    30, 70,
    40, 60,
    0.01, 99.99,
    0.001, 99.999,
]

# 累積出現度数プロットの縦軸に表示する百分率目盛り。0%/100%付近ほど対数的に
# 間隔を広げ、50%を中心に対称になるようにする（"確率紙"と同様の考え方）。
_PERCENTILE_TICKS = [
    0.001, 0.01, 0.1, 1, 5, 10, 20, 30, 40,
    50,
    60, 70, 80, 90, 95, 99, 99.9, 99.99, 99.999,
]


def _percentile_to_y(p: float) -> float:
    """百分率(0-100)を、50%を中心に対称な対数スケールの座標へ変換する。

    p<=50 は log10(p)、p>50 は 100-p を基準にした鏡像。0%/100%そのものは
    定義できない（log(0)）ため、呼び出し側で(0, 100)の開区間に収める。
    """
    p = min(max(p, 1e-9), 100 - 1e-9)
    ref = math.log10(50.0)
    if p <= 50.0:
        return math.log10(p)
    return 2 * ref - math.log10(100.0 - p)


def _format_percentile(p: float) -> str:
    return f"{p:g}%"


def _heat_lookup_table(n: int = 256) -> np.ndarray:
    """日変化モードのヒートマップ用カラーマップ(LUT)を生成する。

    密度が低いところほど透明に近い紺、高いところほど赤→橙→白、という
    典型的な「サーモグラフィ」配色。pyqtgraphのバージョン差異に影響されにくいよう、
    ColorMapオブジェクト経由ではなくRGBA配列を直接生成してImageItem.setLookupTable()に渡す。
    """
    stops = [0.0, 0.25, 0.55, 0.8, 1.0]
    colors = [
        (10, 10, 40, 0),
        (40, 60, 180, 140),
        (220, 60, 40, 200),
        (255, 170, 40, 230),
        (255, 255, 255, 255),
    ]
    xs = np.linspace(0.0, 1.0, n)
    lut = np.empty((n, 4), dtype=np.ubyte)
    for channel in range(4):
        channel_stops = [c[channel] for c in colors]
        lut[:, channel] = np.interp(xs, stops, channel_stops).astype(np.ubyte)
    return lut


class _ModalBottomAxis(pg.AxisItem):
    """通常/日変化/頻度分析モードに応じて目盛り表示を切り替える横軸。

    pyqtgraphのPlotItem内部レイアウトを都度操作して軸オブジェクトを差し替える実装は、
    タイミングによってPlotItemの内部状態を壊すリスクがあるため採用しない。
    軸インスタンス自体は生成後固定し、表示モード(display_mode)だけを切り替える設計にしている。
    """

    def __init__(self, orientation="bottom"):
        super().__init__(orientation=orientation)
        self.display_mode = GraphMode.NORMAL

    def set_display_mode(self, mode: GraphMode) -> None:
        self.display_mode = mode
        self.picture = None  # 目盛り描画キャッシュを破棄し、次の再描画でtickStringsを呼ばせる
        self.update()

    def tickStrings(self, values, scale, spacing):
        if self.display_mode == GraphMode.NORMAL:
            return self._format_datetime_ticks(values, spacing)
        if self.display_mode == GraphMode.DAILY_OVERLAY:
            return self._format_hhmm_ticks(values)
        return super().tickStrings(values, scale, spacing)

    def tickValues(self, minVal, maxVal, size):
        if self.display_mode not in (GraphMode.NORMAL, GraphMode.DAILY_OVERLAY):
            return super().tickValues(minVal, maxVal, size)
        if maxVal <= minVal or size <= 0:
            return [(1.0, [])]
        step = _choose_nice_time_step(maxVal - minVal, size)
        start = math.floor(minVal / step) * step
        values = []
        v = start
        count = 0
        max_count = 2000  # 極端なsize/spanの組み合わせでも無限ループにならないための安全弁
        while v <= maxVal + step * 0.5 and count < max_count:
            if v >= minVal - step * 0.5:
                values.append(v)
            v += step
            count += 1
        return [(step, values)]

    @staticmethod
    def _format_datetime_ticks(values, spacing) -> list:
        strings = []
        for v in values:
            try:
                dt = datetime.fromtimestamp(v, tz=timezone.utc)
            except (ValueError, OSError, OverflowError):
                strings.append("")
                continue
            fmt = "%Y-%m-%d" if spacing >= 86400 else "%m/%d %H:%M"
            strings.append(dt.strftime(fmt))
        return strings

    @staticmethod
    def _format_hhmm_ticks(values) -> list:
        strings = []
        for v in values:
            v = v % 86400
            h, rem = divmod(int(v), 3600)
            m = rem // 60
            strings.append(f"{h:02d}:{m:02d}")
        return strings


class _CumulativeFreqAxis(pg.AxisItem):
    """累積出現度数モード用の縦軸。

    0.001%〜99.999%の百分率目盛りを、50%を中心に対称な対数スケールで表示する。
    他モードでは無効化し、通常のAxisItemの挙動（数値の自動目盛り）に委ねる。
    """

    def __init__(self, orientation="left"):
        super().__init__(orientation=orientation)
        self.active = False
        self._ticks = [(_percentile_to_y(p), _format_percentile(p)) for p in _PERCENTILE_TICKS]

    def set_active(self, active: bool) -> None:
        self.active = active
        self.picture = None
        self.update()

    def tickValues(self, minVal, maxVal, size):
        if not self.active:
            return super().tickValues(minVal, maxVal, size)
        if size <= 0 or maxVal <= minVal:
            return [(1.0, [])]
        # ラベル同士が重ならないための最小間隔(px)。フォントサイズに対する目安値。
        min_gap_px = 24.0
        min_gap_data = (maxVal - minVal) * min_gap_px / size
        accepted: list[float] = []
        for p in _PERCENTILE_TICK_PRIORITY:
            y = _percentile_to_y(p)
            if y < minVal - 1e-6 or y > maxVal + 1e-6:
                continue
            if any(abs(y - a) < min_gap_data for a in accepted):
                continue
            accepted.append(y)
        accepted.sort()
        return [(1.0, accepted)]

    def tickStrings(self, values, scale, spacing):
        if not self.active:
            return super().tickStrings(values, scale, spacing)
        lookup = {round(y, 6): label for y, label in self._ticks}
        return [lookup.get(round(v, 6), "") for v in values]


class _EdgeOnlyLinearRegionItem(pg.LinearRegionItem):
    """統計範囲選択用のLinearRegionItem（境界線のドラッグのみリサイズを受け付ける）。

    標準のLinearRegionItemは、境界線(edge)だけでなく領域内部（帯の中）のドラッグでも
    領域全体を平行移動できてしまう。これはpyqtgraphの既定動作である
    「左ドラッグ＝パン（ズーム率を変えずに表示範囲だけ移動）」と同じマウス操作を
    奪い合ってしまうため、領域内部のドラッグはここで無視し、下にあるViewBoxの
    パン操作に回す。境界線自体（self.lines、それぞれ独立したInfiniteLine）は
    このオーバーライドの影響を受けず、従来どおりドラッグしてリサイズできる。
    """

    def mouseDragEvent(self, ev):
        ev.ignore()


class GraphWidget(pg.PlotWidget):
    """時系列データを3モードで描画するウィジェット。

    通常モードはDownsamplerで間引いたmin/max帯＋mean線、日変化モードは
    0:00-23:59タイムラインへの重ね合わせ、頻度分析モードは値に対する
    累積出現度数（百分率、50%を中心に対称な対数軸）。

    グラフ上のクリック位置に対応する時刻を time_clicked シグナルで発火し、
    SyncControllerが地図側のピン移動に使う想定（通常/日変化モードのみ意味を持つ）。
    """

    time_clicked = pyqtSignal(object)  # object = np.datetime64（PyQt6はdatetime64を直接扱えないため）
    range_selected = pyqtSignal(object, object)  # (start, end)。通常モードのみnp.datetime64、それ以外はfloat
    view_range_changed = pyqtSignal(float, float)  # (start_epoch_sec, end_epoch_sec)。通常モードのみ発火

    def __init__(self, parent=None):
        self._bottom_axis = _ModalBottomAxis(orientation="bottom")
        self._left_axis = _CumulativeFreqAxis(orientation="left")
        super().__init__(parent, axisItems={"bottom": self._bottom_axis, "left": self._left_axis})
        self._mode = GraphMode.NORMAL
        self._downsampler = Downsampler()
        self._region: pg.LinearRegionItem | None = None
        self._range_selection_enabled = False
        self._line_color = pg.mkColor(*_DEFAULT_LINE_COLOR)
        self._suppress_view_signal = False  # set_time_range()によるプログラム的な変更で再帰通知しないようにするフラグ
        self._y_autoscale_enabled = False  # 表示範囲(X)に応じて縦軸を自動調整するか(チェックボックスで切替)
        # Y軸自動調整用に、直近にplot_normal()で描画したデータを保持しておく
        # （ズーム/パンのたびに元データから再計算するため、間引き後の配列を保持する）
        self._last_plot_x: np.ndarray | None = None
        self._last_plot_y: np.ndarray | None = None
        self._last_plot_y_min: np.ndarray | None = None
        self._last_plot_y_max: np.ndarray | None = None
        self.showGrid(x=True, y=True, alpha=0.3)
        self.getPlotItem().scene().sigMouseClicked.connect(self._on_mouse_clicked)
        self.getPlotItem().vb.sigXRangeChanged.connect(self._on_view_range_changed)

    def set_mode(self, mode: GraphMode) -> None:
        self._mode = mode

    @property
    def mode(self) -> GraphMode:
        return self._mode

    def enable_range_selection(self, enabled: bool) -> None:
        """統計値の範囲選択用ドラッグ領域(LinearRegionItem)の表示可否を切り替える。

        累積出現度数モードなど時間軸を持たないモードでは呼び出し側で無効化する想定。
        """
        self._range_selection_enabled = enabled
        if not enabled:
            self._remove_region()

    def clear_range_selection(self) -> None:
        self._remove_region()

    def set_time_range(self, start_sec: float, end_sec: float) -> None:
        """外部(地図側)からグラフの表示範囲(横軸)をズームさせる。

        地図をパン/ズームした結果に応じてグラフをその時間帯に合わせるため、
        SyncControllerから呼ばれる想定。ここで発生するsigXRangeChangedは
        view_range_changedとして再発火させない（地図側へ通知が返り、
        ループになるのを防ぐため）。通常モード以外では何もしない。
        """
        if self._mode != GraphMode.NORMAL or start_sec >= end_sec:
            return
        self._suppress_view_signal = True
        try:
            self.getPlotItem().vb.setXRange(start_sec, end_sec, padding=0)
            if self._y_autoscale_enabled:
                self._autoscale_y_to_visible(start_sec, end_sec)
        finally:
            self._suppress_view_signal = False

    def set_y_autoscale_enabled(self, enabled: bool) -> None:
        """表示範囲(X)に応じて縦軸を自動調整する機能のON/OFF（UIのチェックボックスから呼ばれる）。

        ONにした瞬間、現在の表示範囲に合わせて即座に縦軸を調整する。
        OFFにした場合は、そのモードの全データを基準にした縦軸範囲に戻す。
        """
        self._y_autoscale_enabled = enabled
        if enabled:
            x_range, _y_range = self.getPlotItem().vb.viewRange()
            self._autoscale_y_to_visible(x_range[0], x_range[1])
        else:
            self._reset_y_to_full_range()

    # --- 外観カスタマイズ -----------------------------------------------------
    def set_line_color(self, color=None) -> None:
        """プロット線の色を設定する。colorがNoneの場合はデフォルト色に戻す。

        次回のplot_normal/plot_daily_overlay/plot_cumulative_frequency呼び出しから反映される。
        """
        self._line_color = pg.mkColor(color) if color is not None else pg.mkColor(*_DEFAULT_LINE_COLOR)

    def set_x_label(self, text: str) -> None:
        self.setLabel("bottom", text if text else None)

    def set_y_label(self, text: str) -> None:
        self.setLabel("left", text if text else None)

    def set_y_tick_spacing(self, interval: float | None) -> None:
        """縦軸(データ軸)の目盛り間隔を手動指定する。Noneの場合は自動間隔に戻す。

        累積出現度数モードでは百分率の固定目盛り(_CumulativeFreqAxis)を使うため、
        このメソッドは影響しない。
        """
        if self._left_axis.active:
            return
        axis = self.getPlotItem().getAxis("left")
        if interval is None or interval <= 0:
            axis.setTickSpacing()  # 引数なしで自動間隔に戻る
        else:
            axis.setTickSpacing(major=interval, minor=interval)

    # --- 通常モード -----------------------------------------------------
    def plot_normal(self, timestamps: np.ndarray, values: np.ndarray, target_points: int = 2000) -> None:
        self.clear()
        self._region = None  # clear()で既存のLinearRegionItemもシーンから除去されるため参照を破棄
        self.setLogMode(x=False, y=False)
        self._bottom_axis.set_display_mode(GraphMode.NORMAL)
        self._left_axis.set_active(False)
        self.getPlotItem().vb.setLimits(xMin=None, xMax=None)  # 日変化モードの範囲固定を解除
        self._last_plot_x = None
        self._last_plot_y = None
        self._last_plot_y_min = None
        self._last_plot_y_max = None

        if len(timestamps) == 0:
            return

        bucket_sec = self._downsampler.auto_bucket_seconds(timestamps, target_points)
        # データ点数がtarget_points未満なら間引かず生データをそのまま描画
        if len(timestamps) <= target_points:
            x = timestamps.astype("datetime64[s]").astype(np.int64).astype(float)
            self.plot(x, values, pen=pg.mkPen(color=self._line_color, width=1.5))
            self._last_plot_x = x
            self._last_plot_y = values
            self.getPlotItem().vb.autoRange()
            self._add_region_if_enabled(x[0], x[-1])
            return

        result = self._downsampler.downsample(timestamps, values, bucket_sec)
        x = result.bucket_times.astype("datetime64[s]").astype(np.int64).astype(float)

        if len(x) == 0:
            # 選択列が全てNaN（未対応のセンサー列や、他ファイルとの結合でNaN埋めされた
            # 区間のみを見ている等）の場合、間引き結果が0件になり得る。x[0]参照で
            # クラッシュしないよう、何もプロットせず終了する。
            self.getPlotItem().vb.autoRange()
            return

        band_color = pg.mkColor(self._line_color)
        band_color.setAlpha(80)
        curve_min = pg.PlotCurveItem(x, result.min_values, pen=None)
        curve_max = pg.PlotCurveItem(x, result.max_values, pen=None)
        band = pg.FillBetweenItem(curve_min, curve_max, brush=pg.mkBrush(band_color))
        self.addItem(curve_min)
        self.addItem(curve_max)
        self.addItem(band)
        self.plot(x, result.mean_values, pen=pg.mkPen(color=self._line_color, width=1.5))
        self._last_plot_x = x
        self._last_plot_y_min = result.min_values
        self._last_plot_y_max = result.max_values
        self.getPlotItem().vb.autoRange()
        self._add_region_if_enabled(x[0], x[-1])

    # --- 日変化モード -----------------------------------------------------
    def plot_daily_overlay(self, timestamps: np.ndarray, values: np.ndarray) -> None:
        self.clear()
        self._region = None
        self.setLogMode(x=False, y=False)
        self._bottom_axis.set_display_mode(GraphMode.DAILY_OVERLAY)
        self._left_axis.set_active(False)
        # Y軸自動調整機能はNORMALモードの時間軸専用のため、日変化モードでは保持データを破棄する
        self._last_plot_x = None
        self._last_plot_y = None
        self._last_plot_y_min = None
        self._last_plot_y_max = None

        if len(timestamps) == 0:
            self.getPlotItem().vb.setLimits(xMin=0, xMax=86400)
            return

        seconds_since_midnight = self._seconds_since_midnight(timestamps)
        x_all = seconds_since_midnight
        y_all = values
        valid = ~np.isnan(y_all)
        x_all, y_all = x_all[valid], y_all[valid]

        if len(x_all) == 0:
            self.getPlotItem().vb.setLimits(xMin=0, xMax=86400)
            return

        # 1日=0-86400秒を横軸、値を縦軸にした2次元ヒストグラムを描き、
        # 出現頻度が高いところほど赤〜白に近づく色(ヒートマップ)で表す。
        # 単純な線の重ね描き(半透明の複数本)より、どの時間帯にどの値が
        # 集中しているかが直感的に分かるようにするため。
        x_bins = 288  # 5分刻み(24h * 60min / 5min)
        y_bins = 120
        y_min, y_max = float(np.min(y_all)), float(np.max(y_all))
        if y_min == y_max:
            y_min -= 0.5
            y_max += 0.5
        hist, x_edges, _y_edges = np.histogram2d(
            x_all, y_all, bins=[x_bins, y_bins], range=[[0, 86400], [y_min, y_max]]
        )
        img = pg.ImageItem(hist)
        img.setLookupTable(_heat_lookup_table())
        img.setLevels((0, max(float(hist.max()), 1.0)))
        img.setRect(QRectF(0, y_min, 86400, y_max - y_min))
        self.addItem(img)

        # 各時間帯(5分刻み)の平均値を、参考として濃い実線で重ねる
        bin_indices = np.clip(np.digitize(x_all, x_edges) - 1, 0, x_bins - 1)
        sums = np.zeros(x_bins)
        counts = np.zeros(x_bins)
        np.add.at(sums, bin_indices, y_all)
        np.add.at(counts, bin_indices, 1)
        with np.errstate(invalid="ignore", divide="ignore"):
            bin_means = np.where(counts > 0, sums / counts, np.nan)
        bin_centers = (x_edges[:-1] + x_edges[1:]) / 2
        mean_valid = ~np.isnan(bin_means)
        if np.any(mean_valid):
            self.plot(
                bin_centers[mean_valid],
                bin_means[mean_valid],
                pen=pg.mkPen(color=(20, 20, 20), width=1.5),
            )

        self.getPlotItem().vb.autoRange()
        # 「日変化」の定義上、横軸は0:00:00〜23:59:59より広がる意味を持たないため固定する
        self.getPlotItem().vb.setLimits(xMin=0, xMax=86400)

    # --- 累積出現度数モード -----------------------------------------------------
    def plot_cumulative_frequency(self, values: np.ndarray) -> None:
        """値に対する累積出現度数(%)を、50%を中心に対称な対数軸でプロットする。

        横軸: 値（小さい順）
        縦軸: 累積出現度数(%)。0.001%〜99.999%の間で、0%/100%に近づくほど
              対数的に間隔が広がる（"確率紙"のような見た目になる）。
        プロット位置(百分率)は Hazen の公式 (i-0.5)/n*100 を用いる。これは
        0%/100%ちょうどを避けつつ点群を均等に配置する一般的な方法で、
        n点で 0% や 100% にちょうど張り付いてlog(0)になる事態を避けられる。
        """
        self.clear()
        self._region = None
        self._bottom_axis.set_display_mode(GraphMode.HISTOGRAM)
        self.setLogMode(x=False, y=False)  # 独自の対称対数軸を使うため標準のlogモードは使わない
        self._left_axis.set_active(True)
        self.getPlotItem().vb.setLimits(xMin=None, xMax=None)  # 日変化モードの範囲固定を解除
        self._last_plot_x = None
        self._last_plot_y = None
        self._last_plot_y_min = None
        self._last_plot_y_max = None

        valid = np.sort(values[~np.isnan(values)])
        n = valid.size
        if n == 0:
            return

        percentiles = (np.arange(1, n + 1) - 0.5) / n * 100.0
        y = np.array([_percentile_to_y(p) for p in percentiles])
        self.plot(
            valid,
            y,
            pen=pg.mkPen(color=self._line_color, width=1.5),
            symbol="o",
            symbolSize=3,
            symbolPen=None,
            symbolBrush=self._line_color,
        )
        self.getPlotItem().vb.autoRange()

    # --- 内部ヘルパー -----------------------------------------------------
    @staticmethod
    def _seconds_since_midnight(timestamps: np.ndarray) -> np.ndarray:
        day_start = timestamps.astype("datetime64[D]").astype("datetime64[ns]")
        return (timestamps.astype("datetime64[ns]") - day_start) / np.timedelta64(1, "s")

    def _add_region_if_enabled(self, x_min: float, x_max: float) -> None:
        if not self._range_selection_enabled or x_min >= x_max:
            return
        self._region = _EdgeOnlyLinearRegionItem(values=[x_min, x_max])
        self._region.sigRegionChangeFinished.connect(self._on_region_changed)
        self.addItem(self._region)

    def _remove_region(self) -> None:
        if self._region is not None:
            self.removeItem(self._region)
            self._region = None

    def _on_region_changed(self) -> None:
        if self._region is None:
            return
        lo, hi = self._region.getRegion()
        if self._mode == GraphMode.NORMAL:
            start = np.datetime64(int(lo), "s")
            end = np.datetime64(int(hi), "s")
        else:
            start, end = float(lo), float(hi)
        self.range_selected.emit(start, end)

    def _on_mouse_clicked(self, event) -> None:
        if self._mode == GraphMode.HISTOGRAM:
            return  # ヒストグラムは時刻軸ではないため同期対象外
        vb = self.getPlotItem().vb
        scene_pos = event.scenePos()
        if not self.getPlotItem().sceneBoundingRect().contains(scene_pos):
            return
        data_pos = vb.mapSceneToView(scene_pos)
        x = data_pos.x()

        if self._mode == GraphMode.NORMAL:
            t = np.datetime64(int(x), "s")
        else:  # DAILY_OVERLAY: x は 0-86400秒。日付情報がないため呼び出し側で当日日付と合成する
            t = float(x)
        self.time_clicked.emit(t)

    def _on_view_range_changed(self, vb, x_range) -> None:
        """マウス操作等によるグラフの拡大/縮小/パンを検知し、地図側の点絞り込みに使う。

        set_time_range()によるプログラム的な変更時は_suppress_view_signalで抑制し、
        地図→グラフ→地図の無限ループを防ぐ。通常モード以外は時間軸として意味が
        ないため発火しない。
        """
        if self._suppress_view_signal or self._mode != GraphMode.NORMAL:
            return
        lo, hi = x_range
        if not (math.isfinite(lo) and math.isfinite(hi)) or lo >= hi:
            return
        if self._y_autoscale_enabled:
            self._autoscale_y_to_visible(lo, hi)
        self.view_range_changed.emit(float(lo), float(hi))

    def _autoscale_y_to_visible(self, x_lo: float, x_hi: float) -> None:
        """現在の横軸表示範囲[x_lo, x_hi]に含まれるデータだけを基準に、縦軸を合わせる。

        plot_normal()が保持した間引き後データ(_last_plot_*)から該当区間を切り出して
        計算する。生データ全体を都度読み直すとズーム操作のたびに重くなるため。
        """
        if self._last_plot_x is None:
            return
        x = self._last_plot_x
        lo_idx = int(np.searchsorted(x, x_lo, side="left"))
        hi_idx = int(np.searchsorted(x, x_hi, side="right"))
        if hi_idx <= lo_idx:
            return

        parts = []
        if self._last_plot_y_min is not None and self._last_plot_y_max is not None:
            parts.append(self._last_plot_y_min[lo_idx:hi_idx])
            parts.append(self._last_plot_y_max[lo_idx:hi_idx])
        elif self._last_plot_y is not None:
            parts.append(self._last_plot_y[lo_idx:hi_idx])
        else:
            return

        y = np.concatenate(parts)
        y = y[~np.isnan(y)]
        if y.size == 0:
            return
        self._apply_y_range(float(y.min()), float(y.max()))

    def _reset_y_to_full_range(self) -> None:
        """Y軸自動調整をOFFにした際、全データを基準にした縦軸範囲へ戻す。"""
        if self._last_plot_y_min is not None and self._last_plot_y_max is not None:
            y = np.concatenate([self._last_plot_y_min, self._last_plot_y_max])
        elif self._last_plot_y is not None:
            y = self._last_plot_y
        else:
            return
        y = y[~np.isnan(y)]
        if y.size == 0:
            return
        self._apply_y_range(float(y.min()), float(y.max()))

    def _apply_y_range(self, y_min: float, y_max: float) -> None:
        if y_min == y_max:
            y_min -= 0.5
            y_max += 0.5
        pad = (y_max - y_min) * 0.05
        self.getPlotItem().vb.setYRange(y_min - pad, y_max + pad, padding=0)
