from __future__ import annotations

from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QPlainTextEdit, QVBoxLayout, QWidget


class LogPanel(QWidget):
    """データ読み込み時の詳細ログ（警告・列構成差異など）を表示する読み取り専用パネル。

    従来は左パネルの1行ステータスラベルに全警告を詰め込んでいたため、警告が
    増えると読みにくくなっていた。詳細ログはここに集約し、左パネルには
    件数のみを表示するようにする。GPSデータが無いファイルを読み込んだ際は、
    右側パネルの地図表示エリアをこのログパネルに差し替えて表示する
    （SplitterContainer.show_log() 参照）。
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        self._view = QPlainTextEdit()
        self._view.setReadOnly(True)
        self._view.setPlaceholderText(
            "データ読み込み時の警告・注記はここに表示されます。\n"
            "GPS(緯度/経度)列があるデータを読み込むと、ここが地図表示に切り替わります。"
        )
        font = QFont("Consolas")
        font.setStyleHint(QFont.StyleHint.Monospace)
        self._view.setFont(font)

        layout = QVBoxLayout(self)
        layout.addWidget(self._view)
        layout.setContentsMargins(0, 0, 0, 0)

    def set_log(self, lines: list[str]) -> None:
        """現在のログ内容を全置換する（フォルダ読み込み・追加読み込みのたびに呼ぶ想定）。"""
        self._view.setPlainText("\n".join(lines) if lines else "警告はありません。")

    def append_log(self, text: str) -> None:
        self._view.appendPlainText(text)

    def clear(self) -> None:
        self._view.clear()
