from __future__ import annotations

from pathlib import Path

import numpy as np
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QScrollArea, QSplitter, QVBoxLayout, QWidget

from app.core.data_manager import DataManager
from app.core.stats_engine import StatsEngine
from app.gui.left_panel.appearance_panel import AppearancePanel
from app.gui.left_panel.column_panel import ColumnPanel
from app.gui.left_panel.file_panel import FilePanel
from app.gui.left_panel.mapping_panel import MappingPanel
from app.gui.left_panel.mode_panel import ModePanel
from app.gui.left_panel.output_panel import OutputPanel
from app.gui.left_panel.stats_panel import StatsPanel
from app.gui.right_panel.graph_widget import GraphMode
from app.gui.right_panel.splitter_container import SplitterContainer
from app.gui.sync_controller import SyncController
from app.utils.export_utils import copy_widget_to_clipboard, print_widget

_GPS_COLUMN_NAMES = {"latitude", "longitude"}


class MainWindow(QMainWindow):
    """3画面分割レイアウトの統括クラス。

    左側：ファイル管理・設定・解析結果パネル群
    右側：SplitterContainer（上段グラフ／下段地図、QSplitterで可変）

    データ処理の実体はDataManager/StatsEngineに委譲し、MainWindowは
    パネル間のシグナル配線（Mediator）に徹する。
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Multi-Dimensional Logger Analyzer")
        self.resize(1280, 800)

        self._data_manager = DataManager()
        self._stats_engine = StatsEngine()
        self._current_mode = GraphMode.NORMAL
        self._current_column: str | None = None
        self._current_range: tuple | None = None  # (start, end) 範囲選択中の場合のみ設定

        self.file_panel = FilePanel()
        self.mapping_panel = MappingPanel()
        self.mode_panel = ModePanel()
        self.column_panel = ColumnPanel()
        self.appearance_panel = AppearancePanel()
        self.stats_panel = StatsPanel()
        self.output_panel = OutputPanel()

        self.splitter_container = SplitterContainer()
        self._sync_controller = SyncController(
            self.splitter_container.graph_widget,
            self.splitter_container.map_widget,
            self._data_manager,
        )

        self._build_layout()
        self._connect_signals()

    def _build_layout(self) -> None:
        left_content = QWidget()
        left_layout = QVBoxLayout(left_content)
        for w in (
            self.file_panel,
            self.mapping_panel,
            self.column_panel,
            self.appearance_panel,
            self.mode_panel,
            self.output_panel,
            self.stats_panel,
        ):
            left_layout.addWidget(w)
        left_layout.addStretch(1)

        # 左パネルは項目数が増えても操作できるようスクロール可能にする
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setWidget(left_content)
        left_scroll.setMinimumWidth(280)
        left_scroll.setMaximumWidth(380)

        main_splitter = QSplitter(Qt.Orientation.Horizontal)
        main_splitter.addWidget(left_scroll)
        main_splitter.addWidget(self.splitter_container)
        main_splitter.setStretchFactor(0, 0)
        main_splitter.setStretchFactor(1, 1)

        self.setCentralWidget(main_splitter)

    def _connect_signals(self) -> None:
        self.file_panel.load_folder_requested.connect(self._on_load_folder)
        self.file_panel.append_folder_requested.connect(self._on_append_folder)
        self.file_panel.save_cache_requested.connect(self._on_save_cache)
        self.file_panel.load_cache_requested.connect(self._on_load_cache)

        self.mode_panel.mode_changed.connect(self._on_mode_changed)
        self.column_panel.column_selected.connect(self._on_column_selected)
        self.column_panel.map_visibility_toggled.connect(self.splitter_container.set_map_visible)

        self.output_panel.copy_requested.connect(self._on_copy_requested)
        self.output_panel.print_requested.connect(self._on_print_requested)
        self.mapping_panel.mapping_applied.connect(self._on_mapping_applied)

        self.splitter_container.graph_widget.range_selected.connect(self._on_range_selected)
        self.stats_panel.range_clear_requested.connect(self._on_range_clear)
        self.stats_panel.correlation_columns_changed.connect(self._on_correlation_columns_changed)

        self.appearance_panel.color_changed.connect(self._on_color_changed)
        self.appearance_panel.x_label_changed.connect(self.splitter_container.graph_widget.set_x_label)
        self.appearance_panel.y_label_changed.connect(self.splitter_container.graph_widget.set_y_label)
        self.appearance_panel.tick_spacing_changed.connect(
            self.splitter_container.graph_widget.set_y_tick_spacing
        )
        self.appearance_panel.y_autoscale_changed.connect(
            self.splitter_container.graph_widget.set_y_autoscale_enabled
        )

    # --- ファイル操作 -----------------------------------------------------
    def _on_load_folder(self, folder: str) -> None:
        self._data_manager.load_folder(Path(folder))
        self._refresh_after_load()

    def _on_append_folder(self, folder: str) -> None:
        self._data_manager.append_folder(Path(folder))
        self._refresh_after_load()

    def _on_save_cache(self, path: str) -> None:
        try:
            self._data_manager.save_cache(Path(path))
            self.file_panel.set_status(f"キャッシュを保存しました: {path}")
        except ValueError as e:
            self.file_panel.set_status(str(e))

    def _on_load_cache(self, path: str) -> None:
        self._data_manager.load_cache(Path(path))
        self._refresh_after_load()

    def _refresh_after_load(self) -> None:
        dataset = self._data_manager.dataset
        # 警告の詳細は件数が多くなりやすいため、左パネルには件数のみを出し、
        # 詳細は右パネル下段のログ表示に集約する（ステータス欄が埋まって
        # 読みにくくなるのを避けるため）。
        self.splitter_container.log_panel.set_log(self._data_manager.warnings)

        if dataset is None:
            summary = "データが読み込めませんでした。"
            if self._data_manager.warnings:
                summary += f"（詳細 {len(self._data_manager.warnings)}件、下のログ欄参照）"
            self.file_panel.set_status(summary)
            self.splitter_container.show_log()
            return

        status = f"{len(dataset):,}行を読み込みました。"
        if self._data_manager.warnings:
            status += f" 警告 {len(self._data_manager.warnings)}件（詳細は下のログ欄）。"
        self.file_panel.set_status(status)

        self._confirm_gps_candidate_if_any(dataset)

        plottable_columns = [c for c in dataset.column_names() if c not in _GPS_COLUMN_NAMES]
        self.column_panel.set_columns(plottable_columns, gps_available=dataset.is_gps())
        self.mapping_panel.set_columns(plottable_columns, dataset.units)
        self.stats_panel.set_columns(plottable_columns)
        self.appearance_panel.set_columns(plottable_columns)
        self._current_column = self._pick_default_column(dataset, plottable_columns)
        self._current_range = None

        map_widget = self.splitter_container.map_widget
        if dataset.is_gps():
            map_widget.set_track(
                dataset.columns["latitude"], dataset.columns["longitude"], dataset.timestamps
            )
            self.splitter_container.show_map()
        else:
            map_widget.set_track(np.array([]), np.array([]))
            map_widget.clear_marker()
            self.splitter_container.show_log()

        self._plot_current()

    def _confirm_gps_candidate_if_any(self, dataset) -> None:
        """ヘッダー無しCSVで緯度/経度らしいと推定された列があれば、確定前に確認する。

        「はい」が選ばれたら latitude/longitude へ改名して地図表示のGPS扱いにする。
        「いいえ」なら列名はそのまま（col1, col2など）にし、必要であれば左パネルの
        列マッピングで利用者が手動指定できるようにする。
        """
        candidate = self._data_manager.pending_gps_candidate
        if candidate is None:
            return
        self._data_manager.pending_gps_candidate = None  # 一度だけ確認する

        lat_col, lon_col = candidate
        if lat_col not in dataset.columns or lon_col not in dataset.columns:
            return  # マージ等で列構成が変わっていた場合は安全のため何もしない

        sample_lat = dataset.columns[lat_col][~np.isnan(dataset.columns[lat_col])][:3]
        sample_lon = dataset.columns[lon_col][~np.isnan(dataset.columns[lon_col])][:3]
        sample_text = ", ".join(
            f"({a:.5f}, {b:.5f})" for a, b in zip(sample_lat, sample_lon)
        )

        reply = QMessageBox.question(
            self,
            "GPSデータの確認",
            f"列 '{lat_col}' と '{lon_col}' が緯度・経度の値の範囲に見えます。\n"
            f"先頭のサンプル値: {sample_text}\n\n"
            "この2列を緯度(latitude)・経度(longitude)として扱い、地図に軌跡を表示しますか？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            dataset.rename_column(lat_col, "latitude")
            dataset.rename_column(lon_col, "longitude")

    @staticmethod
    def _pick_default_column(dataset, plottable_columns: list[str]) -> str | None:
        """初期選択列として、値が全てNaNの列を避け、有効な値を持つ最初の列を選ぶ。

        ヘッダー無しCSVの誤判定などで一部の列が全NaNになるケースがあり、
        そのような列がそのまま初期選択されるとグラフが空になり描画処理が
        クラッシュしうるため、防御的にここで避けておく。
        """
        for name in plottable_columns:
            if np.any(~np.isnan(dataset.columns[name])):
                return name
        return plottable_columns[0] if plottable_columns else None

    # --- モード・列切替 -----------------------------------------------------
    def _on_mode_changed(self, mode: GraphMode) -> None:
        self._current_mode = mode
        # 通常モードで選択中の範囲は保持する（日変化/頻度分析モードはその範囲だけを
        # 対象に再描画するため）。範囲の破棄は「選択解除」操作または新規読み込み時のみ行う。
        self.splitter_container.graph_widget.set_mode(mode)
        self._plot_current()

    def _on_column_selected(self, name: str) -> None:
        self._current_column = name
        self._plot_current()

    def _plot_current(self) -> None:
        dataset = self._data_manager.dataset
        if dataset is None or self._current_column is None:
            return

        graph = self.splitter_container.graph_widget
        graph.set_line_color(self.appearance_panel.color_for(self._current_column))

        if self._current_mode == GraphMode.NORMAL:
            # 通常モードは常に全期間を表示する（この画面上で範囲をドラッグ選択する）。
            graph.enable_range_selection(True)
            graph.plot_normal(dataset.timestamps, dataset.columns[self._current_column])
        else:
            # 日変化/頻度分析モードは、通常モードで範囲選択中であればその範囲のみを対象にする。
            subset = self._current_subset(dataset)
            graph.enable_range_selection(False)
            values = subset.columns[self._current_column]
            if self._current_mode == GraphMode.DAILY_OVERLAY:
                graph.plot_daily_overlay(subset.timestamps, values)
            elif self._current_mode == GraphMode.HISTOGRAM:
                graph.plot_cumulative_frequency(values)

        self._update_stats_for_range()

    def _current_subset(self, dataset):
        """現在選択中の範囲（通常モードで選択したもの）でデータを絞り込む。未選択なら全期間。"""
        if self._current_range is None:
            return dataset
        start, end = self._current_range
        return dataset.slice_by_time(start, end)

    # --- 統計・相関（範囲選択対応） -------------------------------------------
    def _on_range_selected(self, start, end) -> None:
        # このシグナルは通常モードでのドラッグ選択時のみ発火する（他モードはドラッグ無効）。
        # ここでグラフを再描画すると、選択直後にplot_normal()が全域幅で領域を
        # 作り直してしまい、ユーザーが選んだ範囲の見た目が消えてしまうため、
        # 統計欄だけを更新する（日変化/頻度分析モードへの反映はモード切替時に行う）。
        self._current_range = (start, end)
        self._update_stats_for_range()

    def _on_range_clear(self) -> None:
        self._current_range = None
        self.splitter_container.graph_widget.clear_range_selection()
        self._plot_current()

    def _on_correlation_columns_changed(self, col_a: str, col_b: str) -> None:
        self._update_correlation(col_a, col_b)

    def _update_stats_for_range(self) -> None:
        dataset = self._data_manager.dataset
        if dataset is None or self._current_column is None:
            return

        subset = self._current_subset(dataset)
        if self._current_range is not None:
            start, end = self._current_range
            self.stats_panel.set_range_label(f"{start} 〜 {end}")
        else:
            self.stats_panel.set_range_label("全期間")

        values = subset.columns[self._current_column]
        self.stats_panel.update_stats(self._stats_engine.column_stats(values))
        self._update_correlation(
            self.stats_panel.column_a_combo.currentText(),
            self.stats_panel.column_b_combo.currentText(),
            subset,
        )

    def _update_correlation(self, col_a: str, col_b: str, subset=None) -> None:
        dataset = self._data_manager.dataset
        if dataset is None:
            return
        if subset is None:
            subset = self._current_subset(dataset)

        if col_a and col_b and col_a in subset.columns and col_b in subset.columns:
            r = self._stats_engine.pearson_correlation(subset.columns[col_a], subset.columns[col_b])
        else:
            r = float("nan")
        self.stats_panel.update_correlation(r)

    # --- 列マッピング -----------------------------------------------------
    def _on_mapping_applied(self, mappings: list) -> None:
        dataset = self._data_manager.dataset
        if dataset is None:
            return

        try:
            for old_name, new_name, unit in mappings:
                if new_name != old_name:
                    dataset.rename_column(old_name, new_name)
                if unit:
                    dataset.set_unit(new_name, unit)
        except (KeyError, ValueError) as e:
            self.file_panel.set_status(f"マッピング適用エラー: {e}")
            return

        rename_map = {old: new for old, new, _ in mappings}
        if self._current_column in rename_map:
            self._current_column = rename_map[self._current_column]

        plottable_columns = [c for c in dataset.column_names() if c not in _GPS_COLUMN_NAMES]
        self.column_panel.set_columns(
            plottable_columns, gps_available=dataset.is_gps(), checked_name=self._current_column
        )
        self.mapping_panel.set_columns(plottable_columns, dataset.units)
        self.stats_panel.set_columns(plottable_columns)
        self.appearance_panel.set_columns(plottable_columns)
        if self._current_column not in plottable_columns and plottable_columns:
            self._current_column = plottable_columns[0]

        # マッピングでlatitude/longitudeへの改名によりGPS扱いになった/外れた場合に
        # 下段（地図⇔ログ）表示を追従させる。
        if dataset.is_gps():
            self.splitter_container.map_widget.set_track(
                dataset.columns["latitude"], dataset.columns["longitude"], dataset.timestamps
            )
            self.splitter_container.show_map()
        else:
            self.splitter_container.map_widget.set_track(np.array([]), np.array([]))
            self.splitter_container.map_widget.clear_marker()
            self.splitter_container.show_log()

        self._plot_current()
        self.file_panel.set_status("列マッピングを適用しました。")

    # --- 外観カスタマイズ -----------------------------------------------------
    def _on_color_changed(self, column_name: str, color) -> None:
        if column_name == self._current_column:
            self.splitter_container.graph_widget.set_line_color(color)
            self._plot_current()

    # --- 出力 -----------------------------------------------------
    def _on_copy_requested(self) -> None:
        copy_widget_to_clipboard(self.splitter_container.graph_widget)
        self.file_panel.set_status("グラフをクリップボードにコピーしました。")

    def _on_print_requested(self) -> None:
        printed = print_widget(self.splitter_container.graph_widget, self)
        if printed:
            self.file_panel.set_status("印刷を実行しました。")
