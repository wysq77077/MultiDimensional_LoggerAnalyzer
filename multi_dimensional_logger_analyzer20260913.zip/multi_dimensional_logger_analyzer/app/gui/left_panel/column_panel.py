from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QCheckBox, QGroupBox, QVBoxLayout, QWidget


class ColumnPanel(QWidget):
    """読み込んだ列の表示切替チェックボックス、およびGPS/地図表示ON-OFF。

    暫定仕様：現バージョンは単一列表示のみサポートし、チェックを入れると
    他のチェックを自動的に外す（排他動作）。複数列の重ね描きは将来対応。
    """

    column_selected = pyqtSignal(str)
    map_visibility_toggled = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)

        self._group = QGroupBox("表示項目")
        self._layout = QVBoxLayout()
        self._group.setLayout(self._layout)

        self._column_checkboxes: dict[str, QCheckBox] = {}
        self._gps_checkbox: QCheckBox | None = None
        self._updating = False  # 排他制御中の再帰シグナル防止

        outer = QVBoxLayout(self)
        outer.addWidget(self._group)
        outer.setContentsMargins(0, 0, 0, 0)

    def set_columns(
        self, column_names: list[str], gps_available: bool, checked_name: str | None = None
    ) -> None:
        """データ読み込み・マッピング適用後に呼び出し、チェックボックス一覧を再構築する。

        checked_name が column_names に含まれる場合はそれを選択状態にする
        （マッピング適用などでリストを再構築しても、選択中の列を維持するため）。
        """
        for cb in self._column_checkboxes.values():
            self._layout.removeWidget(cb)
            cb.deleteLater()
        self._column_checkboxes.clear()

        if self._gps_checkbox is not None:
            self._layout.removeWidget(self._gps_checkbox)
            self._gps_checkbox.deleteLater()
            self._gps_checkbox = None

        for name in column_names:
            cb = QCheckBox(name)
            cb.toggled.connect(lambda checked, n=name: self._on_column_toggled(n, checked))
            self._layout.addWidget(cb)
            self._column_checkboxes[name] = cb

        if column_names:
            target = checked_name if checked_name in column_names else column_names[0]
            self._column_checkboxes[target].setChecked(True)

        if gps_available:
            self._gps_checkbox = QCheckBox("GPS（地図表示 ON/OFF）")
            # setChecked()より先にtoggledへ接続しておく。逆順だと、初期状態
            # （未チェック→チェック）の変化に対するtoggledシグナルが接続前に
            # 発火してしまい、GPSデータが有効になった直後に地図へ自動的に
            # 切り替わらない（ユーザーが一度OFF/ONし直すまで反映されない）
            # という不具合につながる。
            self._gps_checkbox.toggled.connect(self.map_visibility_toggled.emit)
            self._gps_checkbox.setChecked(True)
            self._layout.addWidget(self._gps_checkbox)

    def _on_column_toggled(self, name: str, checked: bool) -> None:
        if self._updating:
            return
        if not checked:
            return

        self._updating = True
        for other_name, cb in self._column_checkboxes.items():
            if other_name != name:
                cb.setChecked(False)
        self._updating = False

        self.column_selected.emit(name)
