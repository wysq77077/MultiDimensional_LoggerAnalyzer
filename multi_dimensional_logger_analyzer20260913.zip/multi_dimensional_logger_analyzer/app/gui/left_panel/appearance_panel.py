from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


class AppearancePanel(QWidget):
    """グラフ外観のカスタマイズUI（列ごとのプロット色、軸ラベル、目盛り間隔）。

    プロット色は列名ごとに記憶し、列を切り替えても再設定不要にする
    （MainWindow側でcolor_for()を使って現在の列の色をGraphWidgetへ反映する）。
    """

    color_changed = pyqtSignal(str, QColor)
    x_label_changed = pyqtSignal(str)
    y_label_changed = pyqtSignal(str)
    tick_spacing_changed = pyqtSignal(object)  # float、または自動指定時はNone
    y_autoscale_changed = pyqtSignal(bool)  # 表示範囲(X)に応じて縦軸を自動調整するか

    def __init__(self, parent=None):
        super().__init__(parent)

        group = QGroupBox("グラフ外観設定")
        layout = QVBoxLayout()

        # --- 列ごとのカラー指定 ---
        color_row = QHBoxLayout()
        self._column_combo = QComboBox()
        self._color_btn = QPushButton("色を選択...")
        self._color_btn.clicked.connect(self._on_pick_color)
        color_row.addWidget(self._column_combo, 1)
        color_row.addWidget(self._color_btn)
        layout.addLayout(color_row)

        # --- 軸ラベル ---
        label_form = QFormLayout()
        self._x_label_edit = QLineEdit()
        self._x_label_edit.setPlaceholderText("空欄で自動")
        self._y_label_edit = QLineEdit()
        self._y_label_edit.setPlaceholderText("空欄で自動")
        self._x_label_edit.editingFinished.connect(
            lambda: self.x_label_changed.emit(self._x_label_edit.text())
        )
        self._y_label_edit.editingFinished.connect(
            lambda: self.y_label_changed.emit(self._y_label_edit.text())
        )
        label_form.addRow("横軸ラベル:", self._x_label_edit)
        label_form.addRow("縦軸ラベル:", self._y_label_edit)
        layout.addLayout(label_form)

        # --- 目盛り間隔 ---
        self._auto_tick_check = QCheckBox("縦軸目盛りを自動")
        self._auto_tick_check.setChecked(True)
        self._auto_tick_check.toggled.connect(self._on_tick_mode_toggled)

        self._tick_spin = QDoubleSpinBox()
        self._tick_spin.setRange(0.001, 1_000_000.0)
        self._tick_spin.setValue(1.0)
        self._tick_spin.setEnabled(False)
        self._tick_spin.valueChanged.connect(self._on_tick_value_changed)

        layout.addWidget(self._auto_tick_check)
        layout.addWidget(self._tick_spin)

        # --- 表示範囲に応じたY軸自動調整 ---
        self._y_autoscale_check = QCheckBox("表示範囲(ズーム)に応じてY軸を自動調整")
        self._y_autoscale_check.setToolTip(
            "地図の表示範囲やグラフのズームで絞り込んだ時間帯に合わせて、\n"
            "縦軸(データ軸)の範囲もその区間のデータに合わせて自動調整します。"
        )
        self._y_autoscale_check.setChecked(False)
        self._y_autoscale_check.toggled.connect(self.y_autoscale_changed)
        layout.addWidget(self._y_autoscale_check)

        group.setLayout(layout)
        outer = QVBoxLayout(self)
        outer.addWidget(group)
        outer.setContentsMargins(0, 0, 0, 0)

        self._colors: dict[str, QColor] = {}

    def set_columns(self, column_names: list[str]) -> None:
        current = self._column_combo.currentText()
        self._column_combo.blockSignals(True)
        self._column_combo.clear()
        self._column_combo.addItems(column_names)
        if current in column_names:
            self._column_combo.setCurrentText(current)
        self._column_combo.blockSignals(False)

    def color_for(self, column_name: str | None) -> QColor | None:
        if column_name is None:
            return None
        return self._colors.get(column_name)

    def _on_pick_color(self) -> None:
        column_name = self._column_combo.currentText()
        if not column_name:
            return
        initial = self._colors.get(column_name, QColor(30, 80, 200))
        color = QColorDialog.getColor(initial, self, f"「{column_name}」の色を選択")
        if color.isValid():
            self._colors[column_name] = color
            self.color_changed.emit(column_name, color)

    def _on_tick_mode_toggled(self, auto_checked: bool) -> None:
        self._tick_spin.setEnabled(not auto_checked)
        self.tick_spacing_changed.emit(None if auto_checked else self._tick_spin.value())

    def _on_tick_value_changed(self, value: float) -> None:
        if not self._auto_tick_check.isChecked():
            self.tick_spacing_changed.emit(value)
