from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QGroupBox, QPushButton, QVBoxLayout, QWidget


class OutputPanel(QWidget):
    """グラフの出力（クリップボードコピー・印刷）を要求するUI。

    実際の描画処理は行わず、シグナルで通知するのみ（実処理はMainWindow経由でexport_utilsが行う）。
    """

    copy_requested = pyqtSignal()
    print_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        group = QGroupBox("出力")
        layout = QVBoxLayout()

        btn_copy = QPushButton("グラフをクリップボードにコピー")
        btn_print = QPushButton("印刷...")
        btn_copy.clicked.connect(self.copy_requested.emit)
        btn_print.clicked.connect(self.print_requested.emit)

        layout.addWidget(btn_copy)
        layout.addWidget(btn_print)
        group.setLayout(layout)

        outer = QVBoxLayout(self)
        outer.addWidget(group)
        outer.setContentsMargins(0, 0, 0, 0)
