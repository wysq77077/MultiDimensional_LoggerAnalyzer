from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.core.stats_engine import ColumnStats


class StatsPanel(QWidget):
    """統計情報（最大/最小/平均、相関係数）の表示エリア。

    グラフ上でドラッグ範囲選択された場合は、その範囲に対する統計値・相関係数を表示する
    （選択がない場合は全期間が対象）。相関係数は2つの列を選んで計算する。
    """

    correlation_columns_changed = pyqtSignal(str, str)
    range_clear_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        group = QGroupBox("統計情報")
        outer_layout = QVBoxLayout()

        range_row = QHBoxLayout()
        self.range_label = QLabel("対象範囲: 全期間")
        self._clear_range_btn = QPushButton("選択解除")
        self._clear_range_btn.clicked.connect(self.range_clear_requested.emit)
        range_row.addWidget(self.range_label, 1)
        range_row.addWidget(self._clear_range_btn)
        outer_layout.addLayout(range_row)

        form = QFormLayout()
        self.count_label = QLabel("-")
        self.min_label = QLabel("-")
        self.max_label = QLabel("-")
        self.mean_label = QLabel("-")
        form.addRow("データ点数:", self.count_label)
        form.addRow("最小値:", self.min_label)
        form.addRow("最大値:", self.max_label)
        form.addRow("平均値:", self.mean_label)
        outer_layout.addLayout(form)

        corr_form = QFormLayout()
        self.column_a_combo = QComboBox()
        self.column_b_combo = QComboBox()
        self.corr_label = QLabel("-")
        self.column_a_combo.currentTextChanged.connect(self._emit_correlation_columns)
        self.column_b_combo.currentTextChanged.connect(self._emit_correlation_columns)
        corr_form.addRow("項目A:", self.column_a_combo)
        corr_form.addRow("項目B:", self.column_b_combo)
        corr_form.addRow("相関係数 r:", self.corr_label)
        outer_layout.addLayout(corr_form)

        group.setLayout(outer_layout)
        layout = QVBoxLayout(self)
        layout.addWidget(group)
        layout.setContentsMargins(0, 0, 0, 0)

    def set_columns(self, column_names: list[str]) -> None:
        """データ読み込み・マッピング適用後に呼び出し、相関係数用コンボボックスを更新する。

        選択中の値がリストに残っていれば維持し、なければ先頭2列を初期選択する。
        """
        for combo, default_index in ((self.column_a_combo, 0), (self.column_b_combo, 1)):
            current = combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(column_names)
            if current in column_names:
                combo.setCurrentText(current)
            elif len(column_names) > default_index:
                combo.setCurrentIndex(default_index)
            combo.blockSignals(False)
        self._emit_correlation_columns()

    def set_range_label(self, text: str) -> None:
        self.range_label.setText(f"対象範囲: {text}")

    def update_stats(self, stats: ColumnStats) -> None:
        self.count_label.setText(f"{stats.count:,}")
        self.min_label.setText(f"{stats.min:.3f}" if stats.count else "-")
        self.max_label.setText(f"{stats.max:.3f}" if stats.count else "-")
        self.mean_label.setText(f"{stats.mean:.3f}" if stats.count else "-")

    def update_correlation(self, r: float) -> None:
        self.corr_label.setText("-" if r != r else f"{r:.3f}")  # r!=r はNaN判定

    def _emit_correlation_columns(self) -> None:
        col_a = self.column_a_combo.currentText()
        col_b = self.column_b_combo.currentText()
        if col_a and col_b:
            self.correlation_columns_changed.emit(col_a, col_b)
