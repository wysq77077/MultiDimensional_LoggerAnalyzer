from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QFileDialog, QGroupBox, QLabel, QPushButton, QVBoxLayout, QWidget


class FilePanel(QWidget):
    """ファイル読み込み・追加読み込み・バイナリキャッシュ保存/復元のUI。

    実際のI/O処理は行わず、パス選択のみを担当してシグナルで通知する
    （実処理はMainWindow経由でDataManagerが行う）。
    """

    load_folder_requested = pyqtSignal(str)
    append_folder_requested = pyqtSignal(str)
    save_cache_requested = pyqtSignal(str)
    load_cache_requested = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)

        group = QGroupBox("データ読み込み")
        layout = QVBoxLayout()

        self.status_label = QLabel("未読み込み")
        self.status_label.setWordWrap(True)

        btn_load = QPushButton("フォルダを読み込み")
        btn_append = QPushButton("フォルダを追加読み込み")
        btn_save_cache = QPushButton("キャッシュとして保存...")
        btn_load_cache = QPushButton("キャッシュから読み込み...")

        btn_load.clicked.connect(self._on_load_folder)
        btn_append.clicked.connect(self._on_append_folder)
        btn_save_cache.clicked.connect(self._on_save_cache)
        btn_load_cache.clicked.connect(self._on_load_cache)

        for w in (btn_load, btn_append, btn_save_cache, btn_load_cache, self.status_label):
            layout.addWidget(w)
        group.setLayout(layout)

        outer = QVBoxLayout(self)
        outer.addWidget(group)
        outer.setContentsMargins(0, 0, 0, 0)

    def set_status(self, text: str) -> None:
        self.status_label.setText(text)

    def _on_load_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "CSVフォルダを選択")
        if folder:
            self.load_folder_requested.emit(folder)

    def _on_append_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "追加読み込みするCSVフォルダを選択")
        if folder:
            self.append_folder_requested.emit(folder)

    def _on_save_cache(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "キャッシュの保存先", filter="Cache (*.mdla)")
        if path:
            self.save_cache_requested.emit(path)

    def _on_load_cache(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "キャッシュファイルを選択", filter="Cache (*.mdla)")
        if path:
            self.load_cache_requested.emit(path)
