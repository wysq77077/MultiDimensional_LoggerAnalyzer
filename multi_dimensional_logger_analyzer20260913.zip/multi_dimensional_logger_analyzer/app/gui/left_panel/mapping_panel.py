from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QGroupBox,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class MappingPanel(QWidget):
    """列名・単位の手動マッピング設定UI。

    ヘッダーがないCSV（col0, col1, ...と自動採番された場合）や、列名を
    分かりやすい表示名に変更したい場合に使用する。GPS用の予約列
    （latitude/longitude）は対象外とし、呼び出し側で除外して渡す想定。
    """

    mapping_applied = pyqtSignal(list)  # list[tuple[old_name, new_name, unit]]

    _COL_ORIGINAL = 0
    _COL_NAME = 1
    _COL_UNIT = 2

    def __init__(self, parent=None):
        super().__init__(parent)

        group = QGroupBox("列マッピング設定")
        layout = QVBoxLayout()

        self._table = QTableWidget(0, 3)
        self._table.setHorizontalHeaderLabels(["元の列名", "表示名", "単位"])
        self._table.verticalHeader().setVisible(False)
        self._table.horizontalHeader().setSectionResizeMode(
            self._COL_ORIGINAL, QHeaderView.ResizeMode.ResizeToContents
        )
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._table.setMinimumHeight(120)

        btn_apply = QPushButton("マッピングを適用")
        btn_apply.clicked.connect(self._on_apply)

        layout.addWidget(self._table)
        layout.addWidget(btn_apply)
        group.setLayout(layout)

        outer = QVBoxLayout(self)
        outer.addWidget(group)
        outer.setContentsMargins(0, 0, 0, 0)

        self._original_names: list[str] = []

    def set_columns(self, column_names: list[str], units: dict | None = None) -> None:
        """データ読み込み・マッピング適用後に呼び出し、テーブルを再構築する"""
        units = units or {}
        self._original_names = list(column_names)
        self._table.setRowCount(len(column_names))

        for row, name in enumerate(column_names):
            original_item = QTableWidgetItem(name)
            original_item.setFlags(original_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self._table.setItem(row, self._COL_ORIGINAL, original_item)
            self._table.setItem(row, self._COL_NAME, QTableWidgetItem(name))
            self._table.setItem(row, self._COL_UNIT, QTableWidgetItem(units.get(name, "")))

    def _on_apply(self) -> None:
        mappings: list[tuple[str, str, str]] = []
        for row, old_name in enumerate(self._original_names):
            new_name = self._table.item(row, self._COL_NAME).text().strip()
            unit = self._table.item(row, self._COL_UNIT).text().strip()
            if not new_name:
                new_name = old_name
            mappings.append((old_name, new_name, unit))

        new_names = [m[1] for m in mappings]
        if len(set(new_names)) != len(new_names):
            QMessageBox.warning(self, "列マッピングエラー", "表示名が重複しています。列名は一意にしてください。")
            return

        self.mapping_applied.emit(mappings)
