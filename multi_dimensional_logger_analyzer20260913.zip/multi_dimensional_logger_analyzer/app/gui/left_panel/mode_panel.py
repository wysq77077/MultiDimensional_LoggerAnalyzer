from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QButtonGroup, QGroupBox, QRadioButton, QVBoxLayout, QWidget

from app.gui.right_panel.graph_widget import GraphMode

_LABELS = {
    GraphMode.NORMAL: "通常モード（連続時系列）",
    GraphMode.DAILY_OVERLAY: "日変化モード（24時間重ね合わせ）",
    GraphMode.HISTOGRAM: "累積出現度数モード（%、対数軸）",
}


class ModePanel(QWidget):
    """グラフモード切替用のラジオボタン群"""

    mode_changed = pyqtSignal(object)  # object = GraphMode

    def __init__(self, parent=None):
        super().__init__(parent)

        group = QGroupBox("グラフ表示モード")
        layout = QVBoxLayout()
        self._button_group = QButtonGroup(self)

        for mode, label in _LABELS.items():
            btn = QRadioButton(label)
            btn.setProperty("graph_mode", mode)
            if mode == GraphMode.NORMAL:
                btn.setChecked(True)
            self._button_group.addButton(btn)
            layout.addWidget(btn)

        self._button_group.buttonClicked.connect(self._on_button_clicked)
        group.setLayout(layout)

        outer = QVBoxLayout(self)
        outer.addWidget(group)
        outer.setContentsMargins(0, 0, 0, 0)

    def _on_button_clicked(self, button) -> None:
        self.mode_changed.emit(button.property("graph_mode"))
