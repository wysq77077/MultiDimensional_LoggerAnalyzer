from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class Dataset:
    """時系列データを保持する値オブジェクト。

    Attributes:
        timestamps: datetime64[ns] の昇順ソート済み1次元配列
        columns: 列名 -> 数値配列（timestampsと同じ長さ）の辞書
        units: 列名 -> 単位表記（任意、未設定なら空文字）
        source_files: 由来ファイルパスの一覧（再読込・デバッグ用）
    """

    timestamps: np.ndarray
    columns: dict
    units: dict = field(default_factory=dict)
    source_files: list = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.timestamps)

    def column_names(self) -> list:
        return list(self.columns.keys())

    def is_gps(self) -> bool:
        return "latitude" in self.columns and "longitude" in self.columns

    def rename_column(self, old_name: str, new_name: str) -> None:
        """列名を変更する（列マッピング設定UIから使用）。

        latitude/longitudeはGPS判定に使う予約名のため、それらへの/からの
        リネームは呼び出し側（GUI）で事前に除外しておく想定。
        """
        if old_name not in self.columns:
            raise KeyError(f"列 '{old_name}' は存在しません。")
        if new_name == old_name:
            return
        if new_name in self.columns:
            raise ValueError(f"列名 '{new_name}' は既に使用されています。")

        # 挿入順を保つため、辞書を作り直す
        self.columns = {
            (new_name if k == old_name else k): v for k, v in self.columns.items()
        }
        if old_name in self.units:
            self.units[new_name] = self.units.pop(old_name)

    def set_unit(self, name: str, unit: str) -> None:
        if name not in self.columns:
            raise KeyError(f"列 '{name}' は存在しません。")
        self.units[name] = unit

    def slice_by_time(self, start: np.datetime64, end: np.datetime64) -> "Dataset":
        """指定期間のサブセットを返す（グラフ⇔地図の範囲同期などで使用）"""
        mask = (self.timestamps >= start) & (self.timestamps <= end)
        sub_columns = {k: v[mask] for k, v in self.columns.items()}
        return Dataset(self.timestamps[mask], sub_columns, self.units, self.source_files)

    def nearest_index(self, t: np.datetime64) -> int:
        """指定時刻に最も近いインデックスを返す（グラフクリック→地図ピン移動用）"""
        idx = np.searchsorted(self.timestamps, t)
        if idx <= 0:
            return 0
        if idx >= len(self.timestamps):
            return len(self.timestamps) - 1
        before, after = self.timestamps[idx - 1], self.timestamps[idx]
        return idx - 1 if (t - before) <= (after - t) else idx

    def columns_differ_from(self, other: "Dataset") -> tuple[set, set]:
        """他のDatasetと列構成を比較する。

        戻り値は (self にしか無い列, other にしか無い列)。ロガーの機種やファーム
        ウェアの違いでセンサー列数が異なるCSVが混在するケース（GPS衛星捕捉数列の
        有無など）を、呼び出し側が事前に検知して警告するために使う。
        """
        self_keys = set(self.columns.keys())
        other_keys = set(other.columns.keys())
        return self_keys - other_keys, other_keys - self_keys

    def merge(self, other: "Dataset") -> "Dataset":
        """他のDatasetと結合し、時刻順にソートして返す（追加読み込み用）

        列構成が異なる場合でもエラーにはせず、列の和集合を取り、片方にしか
        存在しない列は無いほう側をNaN埋めして結合する（フォーマット違いの
        ファイルが混在していても解析自体は継続できるようにするため）。
        列構成の差異自体を利用者に知らせたい場合は、事前に
        `columns_differ_from` で差分を取得して警告する想定。
        """
        all_keys = list(dict.fromkeys([*self.columns.keys(), *other.columns.keys()]))

        def column_or_nan(dataset: "Dataset", key: str) -> np.ndarray:
            if key in dataset.columns:
                return dataset.columns[key]
            return np.full(len(dataset), np.nan)

        merged_ts = np.concatenate([self.timestamps, other.timestamps])
        merged_columns = {
            k: np.concatenate([column_or_nan(self, k), column_or_nan(other, k)]) for k in all_keys
        }

        # 念のための二重防御: 本来はCSVLoader側でNaT(パース失敗時刻)を除外済みの
        # はずだが、キャッシュ経由の読み込みなど別経路で万一NaTが混入していた
        # 場合に備え、ここでも除外しておく。NaTを残すとソート時にNumPyの仕様で
        # 必ず末尾に来てしまい、期間計算がNaNになってグラフ描画がクラッシュする。
        valid_mask = ~pd.isna(merged_ts)
        if not valid_mask.all():
            merged_ts = merged_ts[valid_mask]
            merged_columns = {k: v[valid_mask] for k, v in merged_columns.items()}

        # 安定ソート: 同一時刻データが元の並び順を保つようにする
        order = np.argsort(merged_ts, kind="mergesort")
        merged_ts = merged_ts[order]
        merged_columns = {k: v[order] for k, v in merged_columns.items()}

        return Dataset(
            timestamps=merged_ts,
            columns=merged_columns,
            units={**self.units, **other.units},
            source_files=self.source_files + other.source_files,
        )
