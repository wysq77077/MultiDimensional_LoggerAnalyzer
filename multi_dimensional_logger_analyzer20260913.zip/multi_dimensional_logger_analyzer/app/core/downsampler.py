from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class DownsampledSeries:
    """間引き後の時系列。

    グラフ描画側は bucket_times を横軸に、min/maxを帯（変動幅）として、
    meanをその中を通る実線として描画する想定。
    """

    bucket_times: np.ndarray  # datetime64[ns]、各バケットの開始時刻
    min_values: np.ndarray
    max_values: np.ndarray
    mean_values: np.ndarray

    def __len__(self) -> int:
        return len(self.bucket_times)


class Downsampler:
    """大容量時系列データを、指定した単位時間ごとのmin/max/meanに圧縮するクラス。

    通常モード（連続時系列）でのプロット高速化に使用する。
    np.minimum.at / np.maximum.at / np.add.at によるベクトル化集計で、
    数百万行でも実用的な速度になるようにしている（Pythonループでバケット走査しない）。
    """

    def downsample(
        self, timestamps: np.ndarray, values: np.ndarray, bucket_seconds: float
    ) -> DownsampledSeries:
        if bucket_seconds <= 0:
            raise ValueError("bucket_seconds は正の値である必要があります。")
        if len(timestamps) == 0:
            empty = np.array([], dtype="datetime64[ns]")
            return DownsampledSeries(empty, np.array([]), np.array([]), np.array([]))

        t_ns = timestamps.astype("datetime64[ns]").astype(np.int64)
        bucket_ns = int(bucket_seconds * 1e9)
        bucket_idx = (t_ns - t_ns[0]) // bucket_ns
        n_buckets = int(bucket_idx[-1]) + 1

        valid = ~np.isnan(values)
        vi = bucket_idx[valid]
        vv = values[valid]

        min_vals = np.full(n_buckets, np.inf)
        max_vals = np.full(n_buckets, -np.inf)
        sums = np.zeros(n_buckets)
        counts = np.zeros(n_buckets, dtype=np.int64)

        if vv.size > 0:
            np.minimum.at(min_vals, vi, vv)
            np.maximum.at(max_vals, vi, vv)
            np.add.at(sums, vi, vv)
            np.add.at(counts, vi, 1)

        has_data = counts > 0
        mean_vals = np.full(n_buckets, np.nan)
        mean_vals[has_data] = sums[has_data] / counts[has_data]
        min_vals[~has_data] = np.nan
        max_vals[~has_data] = np.nan

        bucket_times = timestamps[0] + (
            np.arange(n_buckets, dtype=np.int64) * bucket_ns
        ).astype("timedelta64[ns]")

        return DownsampledSeries(
            bucket_times[has_data],
            min_vals[has_data],
            max_vals[has_data],
            mean_vals[has_data],
        )

    @staticmethod
    def auto_bucket_seconds(timestamps: np.ndarray, target_points: int = 2000) -> float:
        """データの全期間と目標点数から、適切なbucket_secondsを自動算出する。

        実際のデータ点数が target_points 未満の場合、呼び出し側で
        downsample自体をスキップする判断をしてよい。
        """
        if len(timestamps) < 2:
            return 1.0
        span_seconds = (timestamps[-1] - timestamps[0]) / np.timedelta64(1, "s")
        # NaN比較は常にFalseになるため `<= 0` だけだとNaNをすり抜けてしまう
        # （NaT混入時の最終防御。通常はCSVLoader/Dataset.merge側で除外済みのはず）。
        if not (span_seconds > 0):
            return 1.0
        return max(span_seconds / target_points, 1e-3)
