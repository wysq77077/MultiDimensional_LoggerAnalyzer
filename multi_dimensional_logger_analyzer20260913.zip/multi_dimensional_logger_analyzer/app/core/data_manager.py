from __future__ import annotations

from pathlib import Path
from typing import Optional

from app.core.cache_manager import CacheManager
from app.core.csv_loader import CSVLoader
from app.models.dataset import Dataset


class DataManager:
    """GUIから見た唯一の窓口（Facade）。

    CSV一括読み込み・追加読み込み・バイナリキャッシュの保存/復元を統括する。
    """

    def __init__(self) -> None:
        self._loader = CSVLoader()
        self._cache = CacheManager()
        self.dataset: Optional[Dataset] = None
        self.warnings: list[str] = []
        # ヘッダー無しCSVで、中身から緯度/経度らしいと推定された列名ペア(未確定)。
        # GUI側が読み込み直後に確認ダイアログを出すために参照する。
        # 確認済みになったら（改名 or 見送り確定後）Noneに戻す。
        self.pending_gps_candidate: tuple | None = None

    def load_folder(self, folder: Path) -> None:
        """フォルダ内の全CSVを一括読み込みし、内部Datasetを新規作成する"""
        self.dataset = None
        self.warnings = []
        self.pending_gps_candidate = None
        self._load_and_merge(folder)

    def append_folder(self, folder: Path) -> None:
        """既存Datasetに、別フォルダのCSVを追加読み込みして結合する。

        Datasetが未作成の場合は load_folder と同じ挙動になる。
        """
        if self.dataset is None:
            self.load_folder(folder)
            return
        self._load_and_merge(folder)

    def save_cache(self, path: Path) -> None:
        """現在のDatasetを独自バイナリキャッシュとして保存する"""
        if self.dataset is None:
            raise ValueError("キャッシュ保存対象のデータがありません。先にCSVを読み込んでください。")
        self._cache.save(self.dataset, Path(path))

    def load_cache(self, path: Path) -> None:
        """独自バイナリキャッシュから高速復元する（CSV再読み込みをスキップ）"""
        self.dataset = self._cache.load(Path(path))
        self.warnings = []
        self.pending_gps_candidate = None

    def _load_and_merge(self, folder: Path) -> None:
        csv_paths = sorted(Path(folder).glob("*.csv"))
        if not csv_paths:
            self.warnings.append(f"{folder}: CSVファイルが見つかりませんでした。")
            return

        for path in csv_paths:
            try:
                result = self._loader.load(path)
            except ValueError as e:
                self.warnings.append(str(e))
                continue

            self.warnings.extend(result.warnings)

            # 既にlatitude/longitude列が確定している場合や、既に候補を拾って
            # いる場合は上書きしない（最初に見つかった候補のみを確認対象にする）。
            if (
                result.gps_candidate is not None
                and self.pending_gps_candidate is None
                and not (self.dataset is not None and self.dataset.is_gps())
            ):
                self.pending_gps_candidate = result.gps_candidate

            if self.dataset is None:
                self.dataset = result.dataset
                continue

            missing_here, missing_there = self.dataset.columns_differ_from(result.dataset)
            if missing_here or missing_there:
                detail = []
                if missing_there:
                    detail.append(f"このファイルに無い列: {sorted(missing_there)}")
                if missing_here:
                    detail.append(f"このファイルにのみある列: {sorted(missing_here)}")
                self.warnings.append(
                    f"{path.name}: これまでに読み込んだファイルと列構成が異なります"
                    "（ロガーの機種・設定違いなどでファイルフォーマットが混在している可能性があります）。"
                    + " / ".join(detail)
                    + "。不足している列はNaN埋めして結合しました。"
                )

            self.dataset = self.dataset.merge(result.dataset)
