from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ColumnStats:
    count: int
    min: float
    max: float
    mean: float


class StatsEngine:
    """統計値のリアルタイム計算（最大/最小/平均、ピアソン相関）を担当するクラス。

    左パネルの統計表示エリア、および範囲選択時の再計算（Dataset.slice_by_time後）
    の両方から呼ばれる想定。
    """

    def column_stats(self, values: np.ndarray) -> ColumnStats:
        valid = values[~np.isnan(values)]
        if valid.size == 0:
            return ColumnStats(count=0, min=float("nan"), max=float("nan"), mean=float("nan"))
        return ColumnStats(
            count=int(valid.size),
            min=float(valid.min()),
            max=float(valid.max()),
            mean=float(valid.mean()),
        )

    def pearson_correlation(self, x: np.ndarray, y: np.ndarray) -> float:
        """2項目間のピアソン相関係数rを計算する。

        NaNを含む行は両方の配列から除外してから計算する（欠損の多いGPS/センサー
        データを想定した実運用上の配慮）。分散ゼロ（定数列）の場合はnanを返す。
        """
        if len(x) != len(y):
            raise ValueError("相関計算には同じ長さの配列が必要です。")

        valid = ~np.isnan(x) & ~np.isnan(y)
        if valid.sum() < 2:
            return float("nan")

        xv, yv = x[valid], y[valid]
        if np.std(xv) == 0 or np.std(yv) == 0:
            return float("nan")

        return float(np.corrcoef(xv, yv)[0, 1])
