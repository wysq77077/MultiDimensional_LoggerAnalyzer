from __future__ import annotations

import gzip
import pickle
from pathlib import Path

from app.models.dataset import Dataset

# キャッシュファイルの形式バージョン。Datasetの構造を変更した場合はインクリメントし、
# 古いキャッシュを読み込んだ際に安全に「非対応」と判定できるようにする。
_CACHE_FORMAT_VERSION = 1
_CACHE_SUFFIX = ".mdla"  # Multi-Dimensional Logger Analyzer 独自拡張子


class CacheFormatError(Exception):
    """キャッシュファイルの形式が不正、またはバージョン非対応の場合に送出する"""


class CacheManager:
    """Datasetをpickle+gzip圧縮した独自バイナリ形式でローカル保存/復元するクラス。

    numpy配列を含むDatasetをそのままpickle化し、gzipで圧縮する方式を採用。
    npyへの個別分割はせず、単一ファイルで完結させることで管理をシンプルにしている。
    """

    def save(self, dataset: Dataset, path: Path) -> None:
        path = Path(path)
        if path.suffix != _CACHE_SUFFIX:
            path = path.with_suffix(_CACHE_SUFFIX)

        payload = {
            "format_version": _CACHE_FORMAT_VERSION,
            "dataset": dataset,
        }
        with gzip.open(path, "wb", compresslevel=6) as f:
            pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)

    def load(self, path: Path) -> Dataset:
        path = Path(path)
        try:
            with gzip.open(path, "rb") as f:
                payload = pickle.load(f)
        except (OSError, pickle.UnpicklingError, EOFError) as e:
            raise CacheFormatError(f"{path.name}: キャッシュファイルを読み込めませんでした ({e})") from e

        if not isinstance(payload, dict) or "dataset" not in payload:
            raise CacheFormatError(f"{path.name}: 不正なキャッシュ形式です。")

        version = payload.get("format_version")
        if version != _CACHE_FORMAT_VERSION:
            raise CacheFormatError(
                f"{path.name}: キャッシュ形式バージョンが非対応です "
                f"(ファイル: v{version}, 対応: v{_CACHE_FORMAT_VERSION})。"
                "CSVから再読み込みしてください。"
            )

        return payload["dataset"]

    @staticmethod
    def suffix() -> str:
        return _CACHE_SUFFIX
