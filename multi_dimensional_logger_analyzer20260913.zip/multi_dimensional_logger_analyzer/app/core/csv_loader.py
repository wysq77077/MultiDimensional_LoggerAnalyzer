from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from app.models.dataset import Dataset
from app.utils.datetime_utils import combine_date_and_time, extract_date_from_filename

# 列名の代表的なエイリアス。実運用では左パネルの手動マッピングで上書き可能にする想定。
_TIME_ALIASES = {"time", "時刻", "timestamp"}
_DATE_ALIASES = {"date", "日付"}
_LAT_ALIASES = {"lat", "latitude", "緯度"}
_LON_ALIASES = {"lon", "lng", "longitude", "経度"}

# ヘッダーがない（列名が col0, col1, ... に自動採番される）CSV向けに、
# セルの中身だけから「日付らしき列」「時刻らしき列」を判定するための正規表現。
# 日付は区切り文字(/ or -)を持つ点、時刻はコロン区切りのみで日付部分を
# 持たない点で明確に区別できるため、誤判定のリスクは低い。
_DATE_ONLY_PATTERN = re.compile(r"^\d{4}[/-]\d{1,2}[/-]\d{1,2}$")
_TIME_ONLY_PATTERN = re.compile(r"^\d{1,2}:\d{1,2}:\d{1,2}(?:\.\d+)?$")


@dataclass
class CSVLoadResult:
    dataset: Dataset
    warnings: list = field(default_factory=list)  # ヘッダー欠如・日付特定失敗などをGUIに伝える
    # ヘッダーが無く、セルの中身から緯度/経度らしいと推定した列名のペア(未確定)。
    # 誤検出のリスクがあるため、この時点ではDataset側の列名は変更せず、
    # GUI側でユーザーに確認を取ってから rename_column で latitude/longitude に
    # 正式採用する想定。該当なしの場合は None。
    gps_candidate: tuple | None = None


class CSVLoader:
    """1ファイル単位のCSV読み込みを担当するクラス。

    複数ファイルの結合・ソートは DataManager 側の責務とし、ここでは行わない。
    """

    def load(self, path: Path) -> CSVLoadResult:
        warnings: list = []
        df, has_header = self._read_with_header_detection(path)

        date_col = self._find_column(df.columns, _DATE_ALIASES)
        time_col = self._find_column(df.columns, _TIME_ALIASES)
        lat_col = self._find_column(df.columns, _LAT_ALIASES)
        lon_col = self._find_column(df.columns, _LON_ALIASES)

        # ヘッダーが無く列名からは日付/時刻列を特定できなかった場合、セルの内容
        # （"2025/11/5" のような日付書式、"0:0:5" のような時刻書式）から推定する。
        # これを行わないと、時刻列が「値」として誤って取り込まれて全てNaNの
        # 列になったり（初期選択時にグラフが空になりクラッシュする）、日付が
        # 欠落して1日分のデータが同一時刻に潰れてしまったりする。
        if date_col is None and time_col is None:
            date_col, time_col = self._detect_date_time_columns_by_content(
                df, exclude={lat_col, lon_col} - {None}
            )

        timestamps, consumed_cols = self._build_timestamps(df, path, date_col, time_col, warnings)

        # パースに失敗した時刻(NaT)があれば、その行を除外した上で件数を警告する。
        # NaTを残したまま複数ファイルを結合すると、ソート時にNumPyの仕様で
        # 必ず配列の末尾に来てしまい、期間計算(グラフの自動間引き幅算出)が
        # NaNになってクラッシュする。どのファイルの何行が原因か分かるよう、
        # ここで最初に検出・除外しておく。
        nat_mask = pd.isna(timestamps)
        nat_count = int(nat_mask.sum())
        if nat_count > 0:
            bad_rows = (np.where(nat_mask)[0] + 1).tolist()  # 1始まりの行番号で表示
            shown = ", ".join(str(r) for r in bad_rows[:10])
            more = f" 他{len(bad_rows) - 10}行" if len(bad_rows) > 10 else ""
            warnings.append(
                f"{path.name}: 時刻をパースできない行が{nat_count}件あったため除外しました "
                f"(行番号: {shown}{more})。該当行のみデータから除かれ、他の行は正常に読み込まれています。"
            )
            keep_mask = ~nat_mask
            timestamps = timestamps[keep_mask]
            df = df.loc[keep_mask].reset_index(drop=True)

        value_cols = [c for c in df.columns if c not in consumed_cols]
        columns = {}
        for c in value_cols:
            name = "latitude" if c == lat_col else "longitude" if c == lon_col else str(c)
            columns[name] = pd.to_numeric(df[c], errors="coerce").to_numpy()

        gps_candidate = None
        if not has_header:
            warnings.append(
                f"{path.name}: ヘッダーが見つからないため列名を自動採番しました "
                "(col0, col1, ...)。左パネルの列マッピングで項目名を手動設定してください。"
            )
            # GPS列(緯度/経度)は列名でしか判定していないため、ヘッダーが無い場合は
            # 自動判定できない。そこで、セルの中身（値の範囲）から緯度/経度らしい
            # 隣接列を推定する。ただし誤検出のリスクがあるため、この場では確定させず
            # 「候補」として警告に含め、GUI側でユーザーに確認を取ってから
            # latitude/longitude への改名を確定する。
            if lat_col is None or lon_col is None:
                exclude = {date_col, time_col} - {None}
                cand_lat, cand_lon = self._detect_lat_lon_columns_by_content(df, exclude)
                if cand_lat is not None:
                    gps_candidate = (str(cand_lat), str(cand_lon))
                    warnings.append(
                        f"{path.name}: 列 '{cand_lat}' と '{cand_lon}' が緯度/経度らしき"
                        "値の範囲でした（要確認）。"
                    )
                elif len(value_cols) >= 2:
                    warnings.append(
                        f"{path.name}: 緯度/経度と思われる列を自動判定できませんでした。"
                        "地図表示を有効にするには、左パネルの列マッピングで該当列の表示名を "
                        "'latitude' と 'longitude' に変更してください。"
                    )

        dataset = Dataset(timestamps=timestamps, columns=columns, source_files=[str(path)])
        return CSVLoadResult(dataset=dataset, warnings=warnings, gps_candidate=gps_candidate)

    def _read_with_header_detection(self, path: Path):
        """1行目が数値または時刻らしき値のみで構成される場合はヘッダーなしとみなす簡易判定。

        時刻列（例: "00:00:00"）はfloat変換できないため、単純な数値判定だけでは
        ヘッダーありと誤判定してしまう。そのため時刻としてパース可能な値も
        「データ」とみなすようにしている。
        """
        preview = pd.read_csv(path, nrows=1, header=None)
        first_row = preview.iloc[0]
        looks_like_data = all(self._looks_like_data_value(v) for v in first_row)

        if looks_like_data:
            df = pd.read_csv(path, header=None)
            df.columns = [f"col{i}" for i in range(len(df.columns))]
            return df, False
        df = pd.read_csv(path, header=0)
        return df, True

    @staticmethod
    def _is_numeric(v) -> bool:
        try:
            float(v)
            return True
        except (TypeError, ValueError):
            return False

    @classmethod
    def _looks_like_data_value(cls, v) -> bool:
        if cls._is_numeric(v):
            return True
        # 数値でなくても、時刻/日付として解釈できる値は「データ」とみなす
        parsed = pd.to_datetime(str(v), errors="coerce")
        return not pd.isna(parsed)

    @staticmethod
    def _find_column(columns, aliases: set):
        for c in columns:
            if str(c).strip().lower() in aliases:
                return c
        return None

    @classmethod
    def _detect_date_time_columns_by_content(cls, df, exclude: set):
        """列名からは日付/時刻列を特定できない場合に、セルの中身から推定する。

        先頭付近の数十行を見て、列内の値がほぼ全て日付書式（例: 2025/11/5）
        または時刻書式（例: 0:0:5, 10:06:42）に一致する列をそれぞれ1つずつ
        採用する。緯度/経度として既に特定済みの列は候補から除外する。
        """
        date_col = None
        time_col = None
        sample_size = min(20, len(df))
        if sample_size == 0:
            return date_col, time_col

        for c in df.columns:
            if c in exclude:
                continue
            sample = df[c].head(sample_size).astype(str).str.strip()
            if date_col is None and sample.map(lambda v: bool(_DATE_ONLY_PATTERN.match(v))).all():
                date_col = c
                continue
            if time_col is None and sample.map(lambda v: bool(_TIME_ONLY_PATTERN.match(v))).all():
                time_col = c

        return date_col, time_col

    @classmethod
    def _detect_lat_lon_columns_by_content(cls, df, exclude: set):
        """列名からは緯度/経度列を特定できない場合に、セルの中身から推定する。

        一般的なGPSロガーのCSVでは緯度の直後の列に経度が続く形式が多いため、
        隣り合う2列のうち、片方が緯度としてあり得る範囲(-90〜90)、
        もう片方が経度としてあり得る範囲(-180〜180)にすべて収まっており、
        かつどちらも値が一定でない（定数列ではない＝移動を記録している列らしい）
        ものを最初に見つけた時点で緯度・経度の候補ペアとして返す。
        あくまで「候補」であり、この時点ではDataset側の列名は変更しない
        （GUI側でユーザー確認後に確定させる）。
        """
        cols = [c for c in df.columns if c not in exclude]
        sample_size = min(20, len(df))
        if sample_size < 2:
            return None, None

        def numeric_sample(c):
            s = pd.to_numeric(df[c].head(sample_size), errors="coerce")
            if s.isna().any():
                return None
            return s

        for i in range(len(cols) - 1):
            a = numeric_sample(cols[i])
            b = numeric_sample(cols[i + 1])
            if a is None or b is None:
                continue
            if a.nunique() <= 1 or b.nunique() <= 1:
                continue  # 定数列は緯度/経度らしくないため除外
            if a.between(-90, 90).all() and b.between(-180, 180).all():
                return cols[i], cols[i + 1]
        return None, None

    def _build_timestamps(self, df, path: Path, date_col, time_col, warnings: list):
        """タイムスタンプ配列と、その生成に消費した列名の集合を返す。

        消費した列（例: 先頭列を日時としてフォールバック利用した場合のその列）は、
        呼び出し側でvalue_colsから除外し、数値データとして誤って取り込まれないようにする。
        """
        if date_col and time_col:
            dt = pd.to_datetime(
                df[date_col].astype(str) + " " + df[time_col].astype(str), errors="coerce"
            )
            return dt.to_numpy(dtype="datetime64[ns]"), {date_col, time_col}

        if time_col and not date_col:
            file_date = extract_date_from_filename(path.stem)
            if file_date is None:
                warnings.append(
                    f"{path.name}: 時刻のみでファイル名から日付を特定できませんでした。"
                    "左パネルで日付を手動指定してください（暫定的に本日の日付を使用）。"
                )
                file_date = pd.Timestamp.today().date()
            timestamps = combine_date_and_time(file_date, df[time_col])
            return timestamps, {time_col}

        # 日付・時刻列いずれも見つからない場合、先頭列を日時としてのフォールバック
        first_col = df.columns[0]
        dt = pd.to_datetime(df[first_col], errors="coerce")
        if dt.isna().all():
            raise ValueError(f"{path.name}: 時刻情報を含む列を特定できませんでした。")
        return dt.to_numpy(dtype="datetime64[ns]"), {first_col}
